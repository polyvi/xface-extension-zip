﻿using System;
using System.Diagnostics;
using System.IO;
using ICSharpCode.SharpZipLib.Zip;

namespace ZipLibrary
{
    public class Zip
    {
        /// <summary>
        /// 功能：压缩文件或文件夹，路径均为绝对路径。
        /// </summary>
        /// <param name="dirPath">被压缩的文件或文件夹路径</param>
        /// <param name="zipFilePath">生成压缩文件的路径，为空则默认与被压缩文件夹同一级目录，名称为：文件夹名+.zip</param>
        /// <returns>是否压缩成功</returns>
        public static bool ZipFile(string dirPath, string zipFilePath)
        {
            if (dirPath == string.Empty)
            {
                Debug.WriteLine("file path is NULL！ ");
                return false;
            }
            bool isFileExist = File.Exists(dirPath);
            bool isDirExist = Directory.Exists(dirPath);
            if (!isFileExist && !isDirExist)
            {
                Debug.WriteLine("Cannot find Directory or file！ ");
                return false;
            }

            //压缩文件名为空时使用文件夹名＋.zip
            if (zipFilePath == string.Empty)
            {
                if (isDirExist)
                {
                    if (dirPath.EndsWith("\\"))
                    {
                        dirPath = dirPath.Substring(0, dirPath.Length - 1);
                    }
                    zipFilePath = dirPath + ".zip";
                }
                else
                {
                    Debug.WriteLine("zipfile path is NULL ");
                    return false;
                }
            }
            else
            {
                string despath = Path.GetDirectoryName(zipFilePath);
                isDirExist = Directory.Exists(despath);
                if (!isDirExist)
                {
                    var info = Directory.CreateDirectory(despath);
                    if (info == null)
                        return false;
                }
            }

            using (ZipOutputStream s = new ZipOutputStream(File.Create(zipFilePath)))
            {
                s.SetLevel(9);
                byte[] buffer = new byte[4096];
                string entryPath = "";
                CompressDir(dirPath, s, entryPath);
            }
            return true;
        }

        /// <summary>
        /// 功能：对多个目录或文件进行zip压缩，路径均为绝对路径。
        /// </summary>
        /// <param name="srcFilePaths">待压缩的文件列表</param>
        /// <param name="zipFileName">要压缩成的zip文件名</param>
        /// <returns>是否压缩成功</returns>
        public static bool ZipFiles(String[] srcFilePaths, String zipFileName)
        {
            if (zipFileName == string.Empty)
            {
                Debug.WriteLine("zipFileName is NULL！ ");
                return false;
            }
            if (srcFilePaths == null)
            {
                Debug.WriteLine("srcFilePaths is NULL！ ");
                return false;
            }

            using (ZipOutputStream s = new ZipOutputStream(File.Create(zipFileName)))
            {
                s.SetLevel(9);
                foreach (String path in srcFilePaths)
                {
                    String entryPath = "";
                    CompressDir(path, s, entryPath);
                }
            }
            return true;
        }

        /// <summary>
        /// 功能：解压zip格式的文件。路径均为绝对路径。
        /// </summary>
        /// <param name="zipFilePath">压缩文件路径</param>
        /// <param name="unZipDir">解压文件存放路径,为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹</param>
        /// <returns>解压是否成功</returns>
        public static bool unZipFile(string zipFilePath, string unZipDir)
        {
            try
            {
                if (zipFilePath == string.Empty)
                {
                    Debug.WriteLine("Zip packet path is NULL！ ");
                    return false;
                }
                if (!File.Exists(zipFilePath))
                {
                    Debug.WriteLine("Cannot find file！ ");
                    return false;
                }
                //解压文件夹为空时默认与压缩文件同一级目录下，跟压缩文件同名的文件夹  
                if (unZipDir == string.Empty)
                    unZipDir = zipFilePath.Replace(Path.GetFileName(zipFilePath), Path.GetFileNameWithoutExtension(zipFilePath));
                if (!unZipDir.EndsWith("\\"))
                    unZipDir += "\\";
                if (!Directory.Exists(unZipDir))
                    Directory.CreateDirectory(unZipDir);

                using (ZipInputStream s = new ZipInputStream(File.OpenRead(zipFilePath)))
                {
                    ZipEntry theEntry;
                    while ((theEntry = s.GetNextEntry()) != null)
                    {
                        string directoryName = Path.GetDirectoryName(theEntry.Name);
                        string fileName = Path.GetFileName(theEntry.Name);
                        if (directoryName.Length > 0)
                        {
                            Directory.CreateDirectory(unZipDir + directoryName);
                        }
                        if (!directoryName.EndsWith("\\"))
                            directoryName += "\\";
                        if (fileName != String.Empty)
                        {
                            using (FileStream streamWriter = File.Create(unZipDir + theEntry.Name))
                            {
                                int size = 2048;
                                byte[] data = new byte[2048];
                                while (true)
                                {
                                    size = s.Read(data, 0, data.Length);
                                    if (size > 0)
                                    {
                                        streamWriter.Write(data, 0, size);
                                    }
                                    else
                                    {
                                        break;
                                    }
                                }
                            }
                        }
                    }//while
                }
                return true;
            }
            catch (ZipException)
            {
                Debug.WriteLine("unZipFile " + zipFilePath + " occur error");
                return false;
            }
        }

        /// <summary>
        /// 压缩一个文件或者文件夹
        /// </summary>
        /// <param name="srcFilePath">待压缩的文件或文件夹</param>
        /// <param name="zos">zip输出流</param>
        /// <param name="entryPath">要写入到zip文件中的文件或文件夹的路径</param>
        private static void CompressDir(String srcFilePath, ZipOutputStream zos, String entryPath)
        {
            if (File.Exists(srcFilePath))
            {
                WriteToZip(srcFilePath, zos, entryPath);
            }
            else
            {
                if (Directory.Exists(srcFilePath))
                {
                    string[] filenames = Directory.GetFiles(srcFilePath);
                    if (filenames != null)
                    {
                        foreach (String pathName in filenames)
                        {
                            WriteToZip(pathName, zos, entryPath);
                        }
                    }
                    string[] dirnames = Directory.GetDirectories(srcFilePath);
                    if (dirnames != null)
                    {
                        foreach (String dirname in dirnames)
                        {
                            if (Directory.Exists(dirname))
                            {
                                CompressDir(dirname, zos, entryPath + Path.GetFileName(dirname) + "\\");
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// 将文件写入zip文件中
        /// </summary>
        /// <param name="srcFile">源文件</param>
        /// <param name="zos">zip输出流</param>
        /// <param name="entryPath">要写入到zip文件中的文件或文件夹的路径</param>
        private static void WriteToZip(string srcFile, ZipOutputStream zos, String entryPath)
        {
            ZipEntry anEntry = null;
            string path = entryPath + Path.GetFileName(srcFile);
            if (Directory.Exists(srcFile))
            {
                anEntry = new ZipEntry(path);
                zos.PutNextEntry(anEntry);
                return;
            }

            anEntry = new ZipEntry(path);
            zos.PutNextEntry(anEntry);
            byte[] buffer = new byte[4096];
            using (FileStream fs = File.OpenRead(srcFile))
            {
                int sourceBytes;
                do
                {
                    sourceBytes = fs.Read(buffer, 0, buffer.Length);
                    zos.Write(buffer, 0, sourceBytes);
                } while (sourceBytes > 0);
            }
        }
    }
}
