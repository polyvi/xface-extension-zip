/**
 * Copyright (c) 2012, Polyvi Inc. All rights reserved.
 * $Id: $
 * */
(function() {
var require,
    define;

(function () {
    var modules = {};

    function build(module) {
        var factory = module.factory;
        module.exports = {};
        delete module.factory;
        factory(require, module.exports, module);
        return module.exports;
    }

    require = function (id) {
        if (!modules[id]) {
            throw "module " + id + " not found";
        }
        return modules[id].factory ? build(modules[id]) : modules[id].exports;
    }

    define = function (id, factory) {
        if (modules[id]) {
            throw "module " + id + " already defined";
        }

        modules[id] = {
            id: id,
            factory: factory
        };
    }

    define.remove = function (id) {
        delete modules[id];
    };

})();

if (typeof module === "object" && typeof require === "function") {
    module.exports.require = require;
    module.exports.define = define;
}

define("xFace/channel", function(require, exports, module) {
var utils = require('xFace/utils');

/**
 * Channel
 * @constructor
 * @param type String ͨ��������
 * @param opts  Object opts��ѡ, Ŀǰ֧�ִ洢�����ص�������onSubscribe��onUnsubscript���ڶ��ĺͷ����Ļص���ʱ�򱻵���
 */
var Channel = function(type, opts) {
    this.type = type;
    this.handlers = {};
    this.numHandlers = 0;
    this.guid = 0;
    this.fired = false;
    this.enabled = true;
    this.events = {
        onSubscribe:null,
        onUnsubscribe:null
    };
    if (opts) {
        if (opts.onSubscribe) this.events.onSubscribe = opts.onSubscribe;
        if (opts.onUnsubscribe) this.events.onUnsubscribe = opts.onUnsubscribe;
    }
},
    channel = {
    /**
     * ���е�ͨ����fire֮�󣬲Ż�ִ���ṩ�ĺ���
     * @param h ��Ҫִ�еĺ���
     * @param c ͨ������
     */
        join: function (h, c) {
            var i = c.length;
            var len = i;
            var f = function() {
                if (!(--i)) h();
            };
            for (var j=0; j<len; j++) {
                !c[j].fired?c[j].subscribeOnce(f):i--;
            }
            if (!i) h();
        },
        create: function (type, opts) {
            channel[type] = new Channel(type, opts);
            return channel[type];
        },

       /**
         * ͨ�����飬���������е�ͨ����devicereadyǰ���ᱻfire.
         */
        deviceReadyChannelsArray: [],
        deviceReadyChannelsMap: {},

        /**
         * ������ʹ��ǰ��Ҫ��ʼ���Ĺ��ܶ���Ҫ���øú���
         * devicereadyǰ�����е��øú����Ĺ��ܶ��ᱻfire
         * @param{String} feature ��������
         **/
         waitForInitialization: function(feature) {
            if (feature) {
                var c = null;
                if (this[feature]) {
                    c = this[feature];
                }
                else {
                    c = this.create(feature);
                }
                this.deviceReadyChannelsMap[feature] = c;
                this.deviceReadyChannelsArray.push(c);
            }
        },

         /**
          * feature��ʼ�������Ѿ���ɣ�����feature�ṩ���ܹ��Ѿ��ܹ�ʹ��
          **/
        initializationComplete: function(feature) {
            var c = this.deviceReadyChannelsMap[feature];
            if (c) {
                c.fire();
            }
        }
    };

function forceFunction(f) {
    if (f === null || f === undefined || typeof f != 'function') throw "Function required as first argument!";
}

/**
 * ����һ������
 */
Channel.prototype.subscribe = function(f, c, g) {
    // need a function to call
    forceFunction(f);

    var func = f;
    if (typeof c == "object") { func = utils.close(c, f); }

    g = g || func.observer_guid || f.observer_guid || this.guid++;
    func.observer_guid = g;
    f.observer_guid = g;
    this.handlers[g] = func;
    this.numHandlers++;
    if (this.events.onSubscribe) this.events.onSubscribe.call(this);
    return g;
};

/**
 * ����һ���������ڸú���ִ��֮�󣬻ᱻ������
 */
Channel.prototype.subscribeOnce = function(f, c) {
    // need a function to call
    forceFunction(f);

    var g = null;
    var _this = this;
    var m = function() {
        f.apply(c || null, arguments);
        _this.unsubscribe(g);
    };
    if (this.fired) {
        if (typeof c == "object") { f = utils.close(c, f); }
        f.apply(this, this.fireArgs);
    } else {
        g = this.subscribe(m);
    }
    return g;
};

/**
 * ��ͨ���з�����һ������
 */
Channel.prototype.unsubscribe = function(g) {
    // need a function to unsubscribe
    if (g === null || g === undefined) { throw "You must pass _something_ into Channel.unsubscribe"; }

    if (typeof g == 'function') { g = g.observer_guid; }
    var handler = this.handlers[g];
    if (handler) {
        this.handlers[g] = null;
        delete this.handlers[g];
        this.numHandlers--;
        if (this.events.onUnsubscribe) this.events.onUnsubscribe.call(this);
    }
};

/**
 * fire ͨ���е����ж��ĵĺ���
 */
Channel.prototype.fire = function(e) {
    if (this.enabled) {
        var fail = false;
        this.fired = true;
        for (var item in this.handlers) {
            var handler = this.handlers[item];
            if (typeof handler == 'function') {
                var rv = (handler.apply(this, arguments)===false);
                fail = fail || rv;
            }
        }
        this.fireArgs = arguments;
        return !fail;
    }
    return true;
};

channel.create('onDOMContentLoaded');

channel.create('onNativeReady');

channel.create('onxFaceReady');

channel.create('onxFaceInfoReady');

channel.create('onxFaceConnectionReady');

channel.create('onDeviceReady');


channel.create('onResume');

channel.create('onPause');

channel.create('onDestroy');

channel.waitForInitialization('onxFaceReady');
channel.waitForInitialization('onxFaceInfoReady');
channel.waitForInitialization('onxFaceConnectionReady');

module.exports = channel;

});


define('xFace', function(require, exports, module) {
var channel = require('xFace/channel');

document.addEventListener('DOMContentLoaded', function() {
    channel.onDOMContentLoaded.fire();
}, false);
if (document.readyState == 'complete') {
    channel.onDOMContentLoaded.fire();
}

var m_document_addEventListener = document.addEventListener;
var m_document_removeEventListener = document.removeEventListener;
var m_window_addEventListener = window.addEventListener;
var m_window_removeEventListener = window.removeEventListener;

var documentEventHandlers = {},
    windowEventHandlers = {}

document.addEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof documentEventHandlers[e] != 'undefined') {
        documentEventHandlers[e].subscribe(handler);
    } else {
        m_document_addEventListener.call(document, evt, handler, capture);
    }
};

window.addEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof windowEventHandlers[e] != 'undefined') {
        windowEventHandlers[e].subscribe(handler);
    } else {
        m_window_addEventListener.call(window, evt, handler, capture);
    }
};

document.removeEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof documentEventHandlers[e] != "undefined") {
        documentEventHandlers[e].unsubscribe(handler);
    } else {
        m_document_removeEventListener.call(document, evt, handler, capture);
    }
};

window.removeEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof windowEventHandlers[e] != "undefined") {
        windowEventHandlers[e].unsubscribe(handler);
    } else {
        m_window_removeEventListener.call(window, evt, handler, capture);
    }
};

function createEvent(type, data) {
  var event = document.createEvent('Events');
  event.initEvent(type, false, false);
  if (data) {
    for (var i in data) {
      if (data.hasOwnProperty(i)) {
        event[i] = data[i];
      }
    }
  }
  return event;
}

if(typeof window.console === "undefined") {
    window.console = {
        log:function(){}
    };
}

var xFace = {
    define:define,
    require:require,
    addWindowEventHandler:function(event, opts) {
      return (windowEventHandlers[event] = channel.create(event, opts));
    },
    addDocumentEventHandler:function(event, opts) {
      return (documentEventHandlers[event] = channel.create(event, opts));
    },
    removeWindowEventHandler:function(event) {
      delete windowEventHandlers[event];
    },
    removeDocumentEventHandler:function(event) {
      delete documentEventHandlers[event];
    },
    getOriginalHandlers: function() {
        return {'document': {'addEventListener': m_document_addEventListener, 'removeEventListener': m_document_removeEventListener},
        'window': {'addEventListener': m_window_addEventListener, 'removeEventListener': m_window_removeEventListener}};
    },
    fireDocumentEvent: function(type, data) {
      var evt = createEvent(type, data);
      if (typeof documentEventHandlers[type] != 'undefined') {
        documentEventHandlers[type].fire(evt);
      } else {
        document.dispatchEvent(evt);
      }
    },
    fireWindowEvent: function(type, data) {
      var evt = createEvent(type,data);
      if (typeof windowEventHandlers[type] != 'undefined') {
        windowEventHandlers[type].fire(evt);
      } else {
        window.dispatchEvent(evt);
      }
    },
    // TODO: this is Android only; think about how to do this better
    shuttingDown:false,
    UsePolling:false,
    // END TODO

    // TODO: iOS only
    // This queue holds the currently executing command and all pending
    // commands executed with xFace.exec().
    commandQueue:[],
    // Indicates if we're currently in the middle of flushing the command
    // queue on the native side.
    commandQueueFlushing:false,
    // END TODO
    /**
     * extension callback mechanism.
     */
    callbackId: 0,
    callbacks:  {},
    callbackStatus: {
        NO_RESULT: 0,
        PROGRESS_CHANGING:1,
        OK: 2,
        CLASS_NOT_FOUND_EXCEPTION: 3,
        ILLEGAL_ACCESS_EXCEPTION: 4,
        INSTANTIATION_EXCEPTION: 5,
        MALFORMED_URL_EXCEPTION: 6,
        IO_EXCEPTION: 7,
        INVALID_ACTION: 8,
        JSON_EXCEPTION: 9,
        ERROR: 10
    },

       callbackSuccess: function(callbackId, args) {
        if (xFace.callbacks[callbackId]) {

            // If result is to be sent to callback
            if (args.status == xFace.callbackStatus.OK) {
                try {
                    if (xFace.callbacks[callbackId].success) {
                        xFace.callbacks[callbackId].success(args.message);
                    }
                }
                catch (e) {
                    console.log("Error in success callback: "+callbackId+" = "+e);
                }
            }

            // Clear callback if not expecting any more results
            if (!args.keepCallback) {
                delete xFace.callbacks[callbackId];
            }
        }
    },
    callbackError: function(callbackId, args) {
        if (xFace.callbacks[callbackId]) {
            try {
                if (xFace.callbacks[callbackId].fail) {
                    xFace.callbacks[callbackId].fail(args.message);
                }
            }
            catch (e) {
                console.log("Error in error callback: "+callbackId+" = "+e);
            }

            // Clear callback if not expecting any more results
            if (!args.keepCallback) {
                delete xFace.callbacks[callbackId];
            }
        }
    },

    callbackStatusChanged : function(callbackId, args){
          if(xFace.callbacks[callbackId]){
                if(args.status == xFace.callbackStatus.PROGRESS_CHANGING){
                    try{
                        if(xFace.callbacks[callbackId].statusChanged){
                            xFace.callbacks[callbackId].statusChanged(args.message);
                        }
                    }catch(e){
                        console.log("Error in statuschageed callback: " + callbackId + "=" + e);
                    }
                }
                if(!args.keepCallback){
                    delete xFace.callbacks[callbackId];
                }
          }
        },
    addPlugin: function(name, obj) {
        if (!window.extensions[name]) {
            window.extensions[name] = obj;
        }
        else {
            console.log("Error: extension "+name+" already exists.");
        }
    },

    addConstructor: function(func) {
        channel.onxFaceReady.subscribeOnce(function() {
            try {
                func();
            } catch(e) {
                console.log("Failed to run constructor: " + e);
            }
        });
    },

    // TODO: ��Ϊ�˹���ֻ���Զ�������ʱʹ�ã����Ƿֹ��̼���
    printScreen: function(imgName, successCallback, errorCallback) {
        var exec = require('xFace/exec');
        exec(successCallback, errorCallback, null, "PrintScreen", "printScreen", [imgName]);
    }
};
// Register pause, resume and deviceready channels as events on document.
channel.onPause = xFace.addDocumentEventHandler('pause');
channel.onResume = xFace.addDocumentEventHandler('resume');
channel.onDeviceReady = xFace.addDocumentEventHandler('deviceready');


/**
 * Legacy variable for extension support
 */
if (!window.xFace) {
    window.xFace =  xFace;
}

/**
 * extensions object
 */
if (!window.extensions) {
    window.extensions = {};
}

module.exports = xFace;

});

/**
 * ʵ��ajax������
 */
define('ajax', function(require, exports, module){
    XMLHttpRequest.prototype.open_raw  = XMLHttpRequest.prototype.open;
	XMLHttpRequest.prototype.open = function(m, u, b){
       var url = redirectUrl(u);
       this.open_raw(m, url, b);
	}

    function redirectUrl(url)
    {
       var TOKEN ="_xface_proxy_ajax_";
       var reurl = url;
       //TODO:https ��֧��
       if(url.indexOf("http") != -1 && getRunningMode() == true)
       {
        //��Ҫ�����ض���
          reurl = "/"+ TOKEN +"/" + url;
       }
       return reurl;
    }

    function getRunningMode()
    {
        var mode = prompt("", "running mode:");
        return (mode == "1" ? true : false);
    }
});


define('localStorage', function(require, exports, module) {
    var xFace = require('xFace');

    var m_window_addEventListener = window.addEventListener;
    var m_window_removeEventListener = window.removeEventListener;

    var m_localStorage_setItem = localStorage.setItem;
    var m_localStorage_getItem = localStorage.getItem;
    var m_localStorage_removeItem = localStorage.removeItem;

    var localstorageFunMap = {};
    var keyPrefix = "_";
    var keySeparator = ",";
    var currentAppId = getAppId();

    function getAppId(){
        var appId = prompt("", "_xFace_get_appId:");
        return appId;
    }

    function getNewKey(appId, key){
        var newKey = appId + keyPrefix + key;
        return newKey;
    }

    window.addEventListener = function(evt, handler, capture) {
        var evtLowCase = evt.toLowerCase();
        if("storage" == evtLowCase){
                var storageCallback = function(storageEvent){
                var key = storageEvent.key;
                var endAppIdIndex = key.indexOf(keyPrefix);
                var eventAppId = key.substr(0, endAppIdIndex);
                if(currentAppId == eventAppId){
                    handler.call(window, evt, capture);
                }
            }
            localstorageFunMap[handler] = storageCallback;
            m_window_addEventListener.call(window, evt, storageCallback, capture);
        } else {
            m_window_addEventListener.call(window, evt, handler, capture);
        }
    };

    window.removeEventListener = function(evt, handler, capture) {
        var e = evt.toLowerCase();
        if("storage" == e){
            m_document_removeEventListener.call(window, evt, localstorageFunMap[handler], capture);
        } else {
            m_window_removeEventListener.call(window, evt, handler, capture);
        }
    };

    localStorage.setItem = function(key, value){
        var newKey = getNewKey(currentAppId, key);
        m_localStorage_setItem.call(localStorage, newKey, value);
        //������appIdΪ��ֵ�����ݣ����д洢�����������ڸ�app��keyֵ
        var keyList = m_localStorage_getItem.call(localStorage, currentAppId);
        if(null == keyList || "" == keyList){
            keyList = key;
            m_localStorage_setItem.call(localStorage, currentAppId, keyList);
        }else{
            var isNewKey = true;
            var keyArray = keyList.split(keySeparator);
            for ( var index = 0; index < keyArray.length; index++){
                var tempKey = keyArray[index];
                if(key == tempKey){
                    isNewKey = false;
                    break;
                }
            }
            if(isNewKey){
                keyList = keyList + keySeparator + key;
                m_localStorage_setItem.call(localStorage, currentAppId, keyList);
            }
        }
    }

    localStorage.getItem = function(key){
        var newKey = getNewKey(currentAppId, key);
        var value = m_localStorage_getItem.call(localStorage, newKey);
        return value;
    }

    localStorage.removeItem = function(key){
        var newKey = getNewKey(currentAppId, key);
        m_localStorage_removeItem.call(localStorage, newKey);
        //���±����keyList��ɾ����Ӧ��key
        var keyList = m_localStorage_getItem.call(localStorage, currentAppId);
        if(null != keyList){
            var keyArray = keyList.split(keySeparator);
            var eraseIndex = -1;
            for ( var index = 0; index < keyArray.length; index++){
                var tempKey = keyArray[index];
                if(key == tempKey){
                    eraseIndex = index;
                    break;
                }
            }
            if(-1 != eraseIndex){
                var newKeyList = "";
                for ( var index = 0; index < keyArray.length; index++){
                    if(index != eraseIndex){
                        if("" == newKeyList){
                            newKeyList = keyArray[index];
                        }else{
                            newKeyList = newKeyList + keySeparator + keyArray[index];
                        }
                    }
                }
                m_localStorage_setItem.call(localStorage, currentAppId, newKeyList);
            }
        }
    }

    localStorage.key = function(index){
        var nonNegative = /^\d+(\.\d+)?$/;
        if(nonNegative.test(index)){
            var realIndex = Math.floor(index);
            var keyList = m_localStorage_getItem.call(localStorage, currentAppId);
            if((null != keyList) && ("" != keyList)){
                var keyArray = keyList.split(keySeparator);
                if(realIndex < keyArray.length){
                    var key = keyArray[realIndex];
                    return key;
                }
            }
        }
        return null;
    }

    localStorage.clear = function(){
        //ɾ����ǰ��app���е����ݣ�keyList�������������ڸ�app��keyֵ������������Ϣ
        //����ɾ��ȫ��������
        self.clearAppData(currentAppId);
    }

    var self = {
        //ɾ��ָ����appId����Ӧ��Ӧ�õ����ݡ�
        clearAppData : function(appId){
            var keyList = m_localStorage_getItem.call(localStorage, appId);
            if(null != keyList){
                var keyArray = keyList.split(keySeparator);
                for ( var index = 0; index < keyArray.length; index++){
                    var key = keyArray[index];
                    var newKey = getNewKey(appId, key);
                    m_localStorage_removeItem.call(localStorage, newKey);
                }
            }
            m_localStorage_removeItem.call(localStorage, appId);
        },
       GSetPreference: m_localStorage_setItem,
       GGetPreference: m_localStorage_getItem,
       GRemovePreference:m_localStorage_removeItem
    }

    module.exports = self;
});

/**
 * ��ģ������app���ͨ��
 */
define('xFace/app', function(require, exports, module){
    var channel = require('xFace/channel');
    var message = channel.create("message");
    var gstorage = require('localStorage');
    var start = channel.create("start");
    var close = channel.create("close");

    var app =
    {
        addEventListener:function(evt, handler){
            var e = evt.toLowerCase();
            if(e == "message"){
                message.subscribe(handler);
            }else if(e == "start"){
                start.subscribe(handler);
            }else if(e == "close"){
                close.subscribe(handler);
            }
        },

        removeEventListener:function(evt, handler){
            var e = evt.toLowerCase();
            if(e == "message"){
                message.unsubscribe(handler);
            }else if(e == "start"){
                start.unsubscribe(handler);
            }else if(e == "close"){
                close.unsubscribe(handler);
            }

        },

        fireAppEvent: function(evt, id){
            var e = evt.toLowerCase();
            if( e == "message"){
               var data = gstorage.GGetPreference.call(localStorage, id);
               gstorage.GRemovePreference.call(localStorage, id); 
               message.fire(data);
            }else if(e == "start"){
                start.fire();
            }else if(e == "close"){
                close.fire();
            }
        },

        sendMessage:function(data, appid){

            function toString(data)
            {
                var result;
                if( typeof data == 'string'){
                    result = data;
                }else if( data != null && typeof data == 'object'){
                    result = data.toString();
                }
                return result;

            }
            
            function generateUniqueMsgId()
            {
                var msgId = parseInt((Math.random() * 65535), 10).toString(10);
                while(null != gstorage.GGetPreference.call(localStorage, msgId))
                {
                     msgId = parseInt((Math.random() * 65535), 10).toString(10);
                }
                return msgId;
            }
 
            var args = arguments;
            if(args.length === 1){
                //�����portal,����Ϣ�����������е�app�������app������Ϣ��������portal
                var msgId = generateUniqueMsgId();
                gstorage.GSetPreference.call(localStorage, msgId, toString(data));
                var success = prompt(msgId, "xFace_app_send_message:");

            }else if(args.length === 2){
                //TODO
                //������Ϣ��ָ����app
                alert('specified app');

            }
        }
    }
    module.exports = app;
});

define('xFace/exec', function(require, exports, module) {

/**
 * ִ����չ����,�����չ��ͬ���򷵻�json��
 * ������첽 �򷵻ؿմ�(�첽����,���ش��뽫�����xFace.callbackSuccess or xFace.callbackError or xFace.callbackStatusChange)
 * @param {Function} success   �ɹ��Ļص�����
 * @param {Function} fail      ʧ�ܵĻص�����
 * @param {String} service     ��չ������
 * @param {String} action      ������չ����Ϊ
 * @param {String[]} [args]    ������չ�Ĳ���
 */
var xFace = require('xFace');

module.exports = function(success, fail, statusChanged,  service, action, args) {
  try {
    var callbackId = service + xFace.callbackId++;
    if (success || fail || statusChanged) {
        xFace.callbacks[callbackId] = {success:success, fail:fail, statusChanged:statusChanged};
    }

    var r = prompt(JSON.stringify(args), "_xFace_jsscript:"+JSON.stringify([service, action, callbackId, true]));

    // If a result was returned
    if (r.length > 0) {
        eval("var v="+r+";");

        // If status is OK, then return value back to caller
        if (v.status === xFace.callbackStatus.OK) {

            // If there is a success callback, then call it now with
            // returned value
            if (success) {
                try {
                    success(v.message);
                } catch (e) {
                    console.log("Error in success callback: " + callbackId  + " = " + e);
                }

                // Clear callback if not expecting any more results
                if (!v.keepCallback) {
                    delete xFace.callbacks[callbackId];
                }
            }
            return v.message;
        }

        // If no result
        else if (v.status === xFace.callbackStatus.NO_RESULT) {
            // Clear callback if not expecting any more results
            if (!v.keepCallback) {
                delete xFace.callbacks[callbackId];
            }
        }

        // If error, then display error
        else {
            console.log("Error: Status="+v.status+" Message="+v.message);

            // If there is a fail callback, then call it now with returned value
            if (fail) {
                try {
                    fail(v.message);
                }
                catch (e1) {
                    console.log("Error in error callback: "+callbackId+" = "+e1);
                }

                // Clear callback if not expecting any more results
                if (!v.keepCallback) {
                    delete xFace.callbacks[callbackId];
                }
            }
            return null;
        }
    }
  } catch (e2) {
    console.log("Error: "+e2);
  }
};

});
define('xFace/common', function(require, exports, module) {
module.exports = {
    objects: {
        xFace: {
            path: 'xFace',
            children: {
                app:{
                  path: 'xFace/app'
                },
                exec: {
                    path: 'xFace/exec'
                },
                AMS:{
                    path:'xFace/extension/ams'
                },
                Message: {
                    path: 'xFace/extension/Message'
                },
                Messaging: {
                    path: 'xFace/extension/Messaging'
                },
                MessageFolderTypes: {
                    path: 'xFace/extension/MessageFolderTypes'
                },
                MessageTypes: {
                    path: 'xFace/extension/MessageTypes'
                },
                Telephony: {
                    path: 'xFace/extension/Telephony',
                    children: {
                        CallRecordTypes: {
                            path: 'xFace/extension/CallRecordTypes'
                        },
                        CallRecord: {
                            path: 'xFace/extension/CallRecord'
                        }
                    }
                },
                UPPCardlessTrans: {
                    path: 'xFace/extension/UPPCardlessTrans'
                },
                HttpTransfer: {
                   path: 'xFace/extension/HttpTransfer'
                },
                AdvancedFileTransfer: {
                    path: 'xFace/extension/AdvancedFileTransfer'
                },
                Security: {
                   path: 'xFace/extension/Security'
                }
            }
        },
        navigator: {
            children: {
                accelerometer: {
                    path: 'xFace/extension/accelerometer'
                },
                compass: {
                    path: 'xFace/extension/compass'
                },
                network: {
                    children: {
                        connection: {
                            path: 'xFace/extension/network'
                        }
                    }
                },
                contacts: {
                    path: 'xFace/extension/contacts'
                },
                notification: {
                    path: 'xFace/extension/Notification'
                },
                battery:{
                    path: 'xFace/extension/battery'
                },
                camera:{
                    path: 'xFace/extension/Camera'
                },
                device:{
                    children:{
                        capture: {
                            path: 'xFace/extension/capture'
                        }
                    }
                }
            }
        },
        Acceleration: {
            path: 'xFace/extension/Acceleration'
        },
        Camera:{
            path: 'xFace/extension/CameraConstants'
        },
        Connection: {
            path: 'xFace/extension/Connection'
        },
        Contact: {
            path: 'xFace/extension/Contact'
        },
        ContactAddress: {
            path: 'xFace/extension/ContactAddress'
        },
        ContactError: {
            path: 'xFace/extension/ContactError'
        },
        ContactField: {
            path: 'xFace/extension/ContactField'
        },
        ContactFindOptions: {
            path: 'xFace/extension/ContactFindOptions'
        },
        ContactName: {
            path: 'xFace/extension/ContactName'
        },
        ContactOrganization: {
            path: 'xFace/extension/ContactOrganization'
        },
        DirectoryEntry: {
            path: 'xFace/extension/DirectoryEntry'
        },
        DirectoryReader: {
            path: 'xFace/extension/DirectoryReader'
        },
        Entry: {
            path: 'xFace/extension/Entry'
        },
        FileEntry: {
            path: 'xFace/extension/FileEntry'
        },
        File: {
            path: 'xFace/extension/File'
        },
        FileError: {
            path: 'xFace/extension/FileError'
        },
        FileWriter: {
            path: 'xFace/extension/FileWriter'
        },
        FileReader: {
            path: 'xFace/extension/FileReader'
        },
        FileTransfer: {
            path: 'xFace/extension/FileTransfer'
        },
        FileTransferError: {
            path: 'xFace/extension/FileTransferError'
        },
        FileSystem: {
            path: 'xFace/extension/FileSystem'
        },
        Flags: {
            path: 'xFace/extension/Flags'
        },
        LocalFileSystem: {
            path: 'xFace/extension/LocalFileSystem'
        },
        Metadata: {
            path: 'xFace/extension/Metadata'
        },
        requestFileSystem: {
            path: 'xFace/extension/requestFileSystem'
        },
        resolveLocalFileSystemURI: {
            path: 'xFace/extension/resolveLocalFileSystemURI'
        },
        ProgressEvent: {
            path: 'xFace/extension/ProgressEvent'
        },
        CompassHeading:{
            path: 'xFace/extension/CompassHeading'
        },
        CompassError:{
            path: 'xFace/extension/CompassError'
        },
        CaptureError: {
            path: 'xFace/extension/CaptureError'
        },
        CaptureAudioOptions:{
            path: 'xFace/extension/CaptureAudioOptions'
        },
        CaptureImageOptions: {
            path: 'xFace/extension/CaptureImageOptions'
        },
        CaptureVideoOptions: {
            path: 'xFace/extension/CaptureVideoOptions'
        },
        ConfigurationData: {
            path: 'xFace/extension/ConfigurationData'
        },
        Media: {
            path: 'xFace/extension/Media'
        },
        MediaError: {
            path: 'xFace/extension/MediaError'
        },
        MediaFile: {
            path: 'xFace/extension/MediaFile'
        },
        MediaFileData:{
            path: 'xFace/extension/MediaFileData'
        }
    }
};

});

define("xFace/platform", function(require, exports, module) {
module.exports = {
  id: "android",
  initialize:function() {
    var channel = require("xFace/channel"),
        xFace = require('xFace'),
        exec = require('xFace/exec');

    channel.onDestroy.subscribe(function() {
      xFace.shuttingDown = true;
    });
    // Inject a listener for the backbutton on the document.
    var backButtonChannel = xFace.addDocumentEventHandler('backbutton', {
      onSubscribe:function() {
        // If we just attached the first handler, let native know we need to override the back button.
        if (this.numHandlers === 1) {
          prompt(JSON.stringify([true]), "_xFace_override_backbutton:");
        }
      },
      onUnsubscribe:function() {
        // If we just detached the last handler, let native know we no longer override the back button.
        if (this.numHandlers === 0) {
          prompt(JSON.stringify([false]), "_xFace_override_backbutton:");
        }
      }
    });
    // Add hardware MENU and SEARCH button handlers
    xFace.addDocumentEventHandler('menubutton');
    xFace.addDocumentEventHandler('searchbutton');

    var storage = require('xFace/extension/android/storage');

    // First patch WebSQL if necessary
    if (typeof window.openDatabase == 'undefined') {
          // Not defined, create an openDatabase function for all to use!
          window.openDatabase = storage.openDatabase;
    } else {
          // Defined, but some Android devices will throw a SECURITY_ERR -
          // so we wrap the whole thing in a try-catch and shim in our own
          // if the device has Android bug 16175.
          var originalOpenDatabase = window.openDatabase;
          window.openDatabase = function(name, version, desc, size) {
              var db = null;
              try {
                  db = originalOpenDatabase(name, version, desc, size);
              }
              catch (ex) {
                    if (ex.code === 18) {
                        db = null;
                    } else {
                        throw ex;
                    }
              }

              if (db === null) {
                    return storage.openDatabase(name, version, desc, size);
              }
              else {
                    return db;
              }
          };
    }
    // Let native code know we are all done on the JS side.
    // Native code will then un-hide the WebView.
    channel.join(function() {
      prompt("", "_xFace_js_init_done:");
    }, [channel.onxFaceReady]);
  },
  objects: {
    navigator: {
        children: {
            //children of navigator on android
            app: {
                path: 'xFace/extension/android/app'
            }
        }
    },
    device: {
        path: 'xFace/extension/android/device'
    },
    File: { // exists natively on Android WebView, override
        path: "xFace/extension/File"
    },
    FileReader: { // exists natively on Android WebView, override
         path: "xFace/extension/FileReader"
    },
    FileError: { //exists natively on Android WebView on Android 4.x
        path: "xFace/extension/FileError"
    },
    console: {
            path: 'xFace/extension/android/console'
    }
  }
};

});
define("xFace/utils", function(require, exports, module) {
var utils = exports;

/**
 * Returns an indication of whether the argument is an array or not
 */
utils.isArray = function(a) {
    return Object.prototype.toString.call(a) == '[object Array]';
};

/**
 * Returns an indication of whether the argument is a Date or not
 */
utils.isDate = function(d) {
    return Object.prototype.toString.call(d) == '[object Date]';
};

/**
 * Does a deep clone of the object.
 */
utils.clone = function(obj) {
    if(!obj || typeof obj == 'function' || utils.isDate(obj) || typeof obj != 'object') {
        return obj;
    }

    var retVal, i;

    if(utils.isArray(obj)){
        retVal = [];
        for(i = 0; i < obj.length; ++i){
            retVal.push(utils.clone(obj[i]));
        }
        return retVal;
    }

    retVal = {};
    for(i in obj){
        if(!(i in retVal) || retVal[i] != obj[i]) {
            retVal[i] = utils.clone(obj[i]);
        }
    }
    return retVal;
};

/**
 * ����һ�������ķ�װ�汾
 */
utils.close = function(context, func, params) {
    if (typeof params == 'undefined') {
        return function() {
            return func.apply(context, arguments);
        };
    } else {
        return function() {
            return func.apply(context, params);
        };
    }
};

/**
 * Create a UUID
 */
utils.createUUID = function() {
    return UUIDcreatePart(4) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(6);
};

/**
 * �����ԭ�������ɷ���
 */
utils.extend = (function() {
    // proxy used to establish prototype chain
    var F = function() {};
    // extend Child from Parent
    return function(Child, Parent) {
        F.prototype = Parent.prototype;
        Child.prototype = new F();
        Child.__super__ = Parent.prototype;
        Child.prototype.constructor = Child;
    };
}());

/**
 * Alert һ����Ϣ����û��alert��ʱ��console�ᱻ����.
 */
utils.alert = function(msg) {
    if (alert) {
        alert(msg);
    } else if (console && console.log) {
        console.log(msg);
    }
};

/**
 * Formats a string and arguments following it ala sprintf()
 *
 * see utils.vformat() for more information
 */
utils.format = function(formatString /* ,... */) {
    var args = [].slice.call(arguments, 1);
    return utils.vformat(formatString, args);
};

/**
 * ��ʽ��һ���ַ���,������vsprintf
 */
utils.vformat = function(formatString, args) {
    if (formatString === null || formatString === undefined) return "";
    if (arguments.length == 1) return formatString.toString();

    var pattern = /(.*?)%(.)(.*)/;
    var rest    = formatString.toString();
    var result  = [];

    while (args.length) {
        var arg   = args.shift();
        var match = pattern.exec(rest);

        if (!match) break;

        rest = match[3];

        result.push(match[1]);

        if (match[2] == '%') {
            result.push('%');
            args.unshift(arg);
            continue;
        }

        result.push(formatted(arg, match[2]));
    }

    result.push(rest);

    return result.join('');
};

//------------------------------------------------------------------------------
function UUIDcreatePart(length) {
    var uuidpart = "";
    for (var i=0; i<length; i++) {
        var uuidchar = parseInt((Math.random() * 256), 10).toString(16);
        if (uuidchar.length == 1) {
            uuidchar = "0" + uuidchar;
        }
        uuidpart += uuidchar;
    }
    return uuidpart;
}

//------------------------------------------------------------------------------
function formatted(object, formatChar) {

    switch(formatChar) {
        case 'j':
        case 'o': return JSON.stringify(object);
        case 'c': return '';
    }

    if (null === object) return Object.prototype.toString.call(object);

    return object.toString();
}

});

define("xFace/builder", function(require, exports, module) {
var utils = require('xFace/utils');

function each(objects, func, context) {
    for (var prop in objects) {
        if (objects.hasOwnProperty(prop)) {
            func.apply(context, [objects[prop], prop]);
        }
    }
}

function include(parent, objects, clobber, merge) {
    each(objects, function (obj, key) {
        try {
          var result = obj.path ? require(obj.path) : {};

          if (clobber) {
              // Clobber if it doesn't exist.
              if (typeof parent[key] === 'undefined') {
                  parent[key] = result;
              } else if (typeof obj.path !== 'undefined') {
                  // If merging, merge properties onto parent, otherwise, clobber.
                  if (merge) {
                      recursiveMerge(parent[key], result);
                  } else {
                      parent[key] = result;
                  }
              }
              result = parent[key];
          } else {
            // Overwrite if not currently defined.
            if (typeof parent[key] == 'undefined') {
              parent[key] = result;
            } else if (merge && typeof obj.path !== 'undefined') {
              // If merging, merge parent onto result
              recursiveMerge(result, parent[key]);
              parent[key] = result;
            } else {
              // Set result to what already exists, so we can build children into it if they exist.
              result = parent[key];
            }
          }

          if (obj.children) {
            include(result, obj.children, clobber, merge);
          }
        } catch(e) {
          utils.alert('Exception building xFace JS globals: ' + e + ' for key "' + key + '"');
        }
    });
}

/**
 * �ݹ�ĺϲ�һ����������Ե���һ�������ϣ����Դ�����Ŀ������������ͬ����Դ���������ֵ�Ḳ��Ŀ�����
 *
 * @param target Ŀ�����
 * @param src    Դ����
 */
function recursiveMerge(target, src) {
    for (var prop in src) {
        if (src.hasOwnProperty(prop)) {
            if (typeof target.prototype !== 'undefined' && target.prototype.constructor === target) {
                // If the target object is a constructor override off prototype.
                target.prototype[prop] = src[prop];
            } else {
                target[prop] = typeof src[prop] === 'object' ? recursiveMerge(
                        target[prop], src[prop]) : src[prop];
            }
        }
    }
    return target;
}

module.exports = {
    build: function (objects) {
        return {
            intoButDontClobber: function (target) {
                include(target, objects, false, false);
            },
            intoAndClobber: function(target) {
                include(target, objects, true, false);
            },
            intoAndMerge: function(target) {
                include(target, objects, true, true);
            }
        };
    }
};

});

define('xFace/extension/ams', function(require, exports, module){
var exec = require('xFace/exec');
var xFace = require('xFace');
var localStorage = require('localStorage');
var AMS = function(){

    //TODO Event handler
};

/**
 * ��װӦ��
 * @param {String} packagePath              Ӧ�ð�װ���������·��������ڵ�ǰӦ�õĹ����ռ䣩
 * @param {Function} successCallback        �ɹ�ʱ�Ļص�����(��װ��ɺ���Ҫ�Ὣappidͨ���ûص���������)
 * @param {Function} errorCallback          ʧ��ʱ�Ļص�����
 * @param {Function} statusChangedCallback  ��װ���̵�״̬�ص�����
 */
AMS.prototype.installApplication = function( packagePath, win, fail, statusChanged)
{
    var me = this;
    exec(
    //Success callback
    function(s)
    {
       win(s);
    },
    //Error callback
    function(e)
    {
      fail(e);

    },
    //statuschanged callback
    function(s)
    {
       statusChanged(s);

    },"AMS", "installApplication",[packagePath]);
};

/**
 * ж��Ӧ��
 * @param {String} appId                    ���ڱ�ʶ��ж��Ӧ�õ�id
 * @param {Function} successCallback        �ɹ�ʱ�Ļص�����
 * @param {Function} errorCallback          ʧ��ʱ�Ļص�����
 */
AMS.prototype.uninstallApplication = function( appId , win, fail)
{
    var me = this;
    exec(
    //Success callback
    function(s)
    {
        //ɾ��Ӧ�ô洢������
        localStorage.clearAppData(appId);
        win(s);
    },
    //Error callback
    function(e)
    {
        fail(e);

    }, null, "AMS", "uninstallApplication",[appId]);
};

/**
 * ����Ӧ��
 * @param {String} appId                    ���ڱ�ʶ������Ӧ�õ�id
 */
AMS.prototype.startApplication = function(appId)
{
    var me = this;
    exec(
    //Success callback
    function(s)
    {
    },
    //Error callback
    function(e)
    {

    }, null, "AMS", "startApplication",[appId]);
};

/**
 * �رյ�ǰӦ��
 */
AMS.prototype.closeApplication = function()
{
    prompt("", "xFace_close_application:");
};

/**
 * ��ȡ�Ѱ�װӦ���б� ����ֵΪjson���飬����Ӧ�õ�icon�����֣�id
   ����:[{"appid":"...", "name":"...","icon":"..." ,"version":"..."},...]
 */
AMS.prototype.listInstalledApplications = function(win, fail)
{
    var me = this;
    var result;
    exec(
    //Success callback
    function(s)
    {
        win(s);
    },
    //Error callback
    function(e)
    {
      fail(e);

    }, null, "AMS", "listInstalledApplications",[]);
    return result;
};

/**
 * ��ȡԤ��Ӧ�ð�
 * */
AMS.prototype.listPresetAppPackages = function(win,fail){
    var success = function(s){
        win(s);
    };
    var error = function(e){
        fail();
    };
    exec(success,error,null,"AMS","listPresetAppPackages",[]);
}
/**
 * ����Ĭ��Ӧ��
 * ����������
 * 1) �û����������ж�Ĭ��Ӧ���Ƿ���Ҫ���£������Ҫ���£���������Ӧ�ĸ��°�
 * 2) Ĭ��Ӧ�ø��°����سɹ��󣬵���updateApplication���и���
 * 3) Ĭ��Ӧ�ø��³ɹ��󣬵���reset�ӿ�����Ĭ��Ӧ��
 */
AMS.prototype.reset = function()
{
    exec(null, null, null, "AMS", "reset", []);
};


/**
 * ����Ӧ��
 * @param {String} packagePath              Ӧ�ø��°��������·��������ڵ�ǰӦ�õĹ����ռ䣩
 * @param {Function} successCallback        �ɹ�ʱ�Ļص�����
 * @param {Function} errorCallback          ʧ��ʱ�Ļص�����
 * @param {Function} statusChangedCallback  ���¹��̵�״̬�ص�����
 */
AMS.prototype.updateApplication = function( packagePath, win, fail, statusChanged)
{
    var me = this;
    exec(
    //Success callback
    function(s)
    {
       win(s);
    },
    //Error callback
    function(e)
    {
      fail(e);

    },
    //statuschanged callback
    function(s)
    {
       statusChanged(s);

    },"AMS", "updateApplication",[packagePath]);

}

module.exports = new AMS();
});

define('xFace/extension/ProgressEvent', function(require, exports, module) {
var ProgressEvent = (function() {
    return function ProgressEvent(type, dict) {
        this.type = type;
        this.bubbles = false;
        this.cancelBubble = false;
        this.cancelable = false;
        this.lengthComputable = false;
        this.loaded = dict && dict.loaded ? dict.loaded : 0;
        this.total = dict && dict.total ? dict.total : 0;
        this.target = dict && dict.target ? dict.target : null;
    };
})();

module.exports = ProgressEvent;
});

define('xFace/extension/Entry', function(require, exports, module) {
var exec = require('xFace/exec'),
    Metadata = require('xFace/extension/Metadata'),
    FileError = require('xFace/extension/FileError');

/**
 * �ļ����У�ʵ�����
 * @param isFile       �ж��Ƿ�Ϊ�ļ���true�����ļ���
 * @param isDirectory  �ж��Ƿ�Ϊ�ļ��У�true�����ļ��У�
 * @param name         �ļ����У�������
 * @param fullPath     �ļ����У��ľ���·��
 */
function Entry(isFile, isDirectory, name, fullPath, fileSystem) {
    this.isFile = (typeof isFile != 'undefined'?isFile:false);
    this.isDirectory = (typeof isDirectory != 'undefined'?isDirectory:false);
    this.name = name || '';
    this.fullPath = fullPath || '';
    this.filesystem = fileSystem || null;
};

/**
 * �ƶ��ļ����У�
 * @param parent  ��Ҫ�ƶ����ĸ�Ŀ¼����
 * @param newName �ƶ��ļ���������֣�Ĭ��Ϊ��ǰ�����֣�
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback   ʧ�ܵĻص�����
 */
Entry.prototype.moveTo = function(parent, newName, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };

    if (!parent) {
        fail(FileError.NOT_FOUND_ERR);
        return;
    }
    // ԭ·��
    var srcPath = this.fullPath,
        name = newName || this.name,
        success = function(entry) {
            if (entry) {
                if (typeof successCallback === 'function') {
                    var result = (entry.isDirectory) ? new (require('xFace/extension/DirectoryEntry'))(entry.name, entry.fullPath) : new (require('xFace/extension/FileEntry'))(entry.name, entry.fullPath);
                    try {
                        successCallback(result);
                    }
                    catch (e) {
                        console.log('Error invoking callback: ' + e);
                    }
                }
            }
            else {
                fail(FileError.NOT_FOUND_ERR);
            }
        };

    exec(success, fail, null, "File", "moveTo", [srcPath, parent.fullPath, name]);
};

/**
 * �����ļ����У�
 * @param parent  ��Ҫ���Ƶ��ĸ�Ŀ¼����
 * @param newName �����ļ���������֣�Ĭ��Ϊ��ǰ�����֣�
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback   ʧ�ܵĻص�����
 */
Entry.prototype.copyTo = function(parent, newName, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };

    if (!parent) {
        fail(FileError.NOT_FOUND_ERR);
        return;
    }

    var srcPath = this.fullPath,
        name = newName || this.name,
        // success callback
        success = function(entry) {
            if (entry) {
                if (typeof successCallback === 'function') {
                    var result = (entry.isDirectory) ? new (require('xFace/extension/DirectoryEntry'))(entry.name, entry.fullPath) : new (require('xFace/extension/FileEntry'))(entry.name, entry.fullPath);
                    try {
                        successCallback(result);
                    }
                    catch (e) {
                        console.log('Error invoking callback: ' + e);
                    }
                }
            }
            else {
                fail(FileError.NOT_FOUND_ERR);
            }
        };

    exec(success, fail, null, "File", "copyTo", [srcPath, parent.fullPath, name]);
};

/**
 * ɾ��һ���ļ����У�������ɾ��һ����Ϊ�յ��ļ��У�Ҳ����ɾ���ļ���Ŀ¼��
 */
Entry.prototype.remove = function(successCallback, errorCallback) {
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(successCallback, fail, null, "File", "remove", [this.fullPath]);
};

/**
 * ����һ�����Ա�ʶ��ʵ���URL
 */
Entry.prototype.toURL = function() {
    // fullPath?��????????URL
    return "file://" + this.fullPath;
};

/**
 * ����һ�����Ա�ʶ��ʵ���URI
 */
Entry.prototype.toURI = function(mimeType) {
    console.log("DEPRECATED: Update your code to use 'toURL'");
    return "file://" + this.fullPath;
};

/**
 * ���Ҹ�Ŀ¼
 */
Entry.prototype.getParent = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var DirectoryEntry = require('xFace/extension/DirectoryEntry');
        var entry = new DirectoryEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, null, "File", "getParent", [this.fullPath]);
};

/**
 * �����ļ���Ԫ����
 */
Entry.prototype.getMetadata = function(successCallback, errorCallback) {
  var success = typeof successCallback !== 'function' ? null : function(lastModified) {
      var metadata = new Metadata(lastModified);
      successCallback(metadata);
  };
  var fail = typeof errorCallback !== 'function' ? null : function(code) {
      errorCallback(new FileError(code));
  };

  exec(success, fail, null, "File", "getMetadata", [this.fullPath]);
};

module.exports = Entry;

});

define('xFace/extension/File', function(require, exports, module) {
/**
 * Constructor.
 * name {DOMString} name of the file, without path information
 * fullPath {DOMString} the full path of the file, including the name
 * type {DOMString} mime type
 * lastModifiedDate {Date} last modified date
 * size {Number} size of the file in bytes
 */

var File = function(name, fullPath, type, lastModifiedDate, size){
    this.name = name || '';
    this.fullPath = fullPath || null;
    this.type = type || null;
    this.lastModifiedDate = lastModifiedDate || null;
    this.size = size || 0;
};

module.exports = File;

});

define('xFace/extension/FileEntry', function(require, exports, module) {
var utils = require('xFace/utils'),
    exec = require('xFace/exec');
    Entry = require('xFace/extension/Entry'),
    File = require('xFace/extension/File'),
    FileWriter = require('xFace/extension/FileWriter'),
    FileError = require('xFace/extension/FileError');

/**
 * An interface representing a file on the file system.
 */
var FileEntry = function(name, fullPath) {
     FileEntry.__super__.constructor.apply(this, [true, false, name, fullPath]);
};

utils.extend(FileEntry, Entry);

FileEntry.prototype.createWriter = function(successCallback, errorCallback) {
    this.file(function(filePointer) {
        var writer = new FileWriter(filePointer);

        if (writer.fileName === null || writer.fileName === "") {
            if (typeof errorCallback === "function") {
                errorCallback(new FileError(FileError.INVALID_STATE_ERR));
            }
        } else {
            if (typeof successCallback === "function") {
                successCallback(writer);
            }
        }
    }, errorCallback);
};

/**
 * Returns a File that represents the current state of the file that this FileEntry represents.
 *
 * @param {Function} successCallback is called with the new File object
 * @param {Function} errorCallback is called with a FileError
 */
FileEntry.prototype.file = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(f) {
        var file = new File(f.name, f.fullPath, f.type, f.lastModifiedDate, f.size);
        successCallback(file);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, null, "File", "getFileMetadata", [this.fullPath]);
};

module.exports = FileEntry;

});

define('xFace/extension/DirectoryEntry', function(require, exports, module) {
var utils = require('xFace/utils'),
    exec = require('xFace/exec'),
    FileError = require('xFace/extension/FileError'),
    Entry = require('xFace/extension/Entry');

/**
 * ���캯��
 */
var DirectoryEntry = function(name, fullPath) {
     DirectoryEntry.__super__.constructor.apply(this, [false, true, name, fullPath]);
};

utils.extend(DirectoryEntry, Entry);

DirectoryEntry.prototype.createReader = function() {
    return new DirectoryReader(this.fullPath);
};

/**
 * �������߲���Ŀ¼
 * @param path      Ŀ¼����Ի��߾���·��
 * @param options   Ŀ¼������ʱ�Ƿ񴴽�
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback   ʧ�ܵĻص�����
 */
DirectoryEntry.prototype.getDirectory = function(path, options, successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var entry = new DirectoryEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, null, "File", "getDirectory", [this.fullPath, path, options]);
};

/**
 * ɾ��һ��Ŀ¼�Լ���Ŀ¼�µ������ļ�����Ŀ¼
 */
DirectoryEntry.prototype.removeRecursively = function(successCallback, errorCallback) {
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(successCallback, fail, null, "File", "removeRecursively", [this.fullPath]);
};

/**
 * �������߲���һ���ļ�
 */
DirectoryEntry.prototype.getFile = function(path, options, successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var FileEntry = require('xFace/extension/FileEntry');
        var entry = new FileEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, null, "File", "getFile", [this.fullPath, path, options]);
};

module.exports = DirectoryEntry;

});

define("xFace/extension/DirectoryReader", function(require, exports, module) {
var exec = require('xFace/exec');

function DirectoryReader(path) {
    this.path = path || null;
}

/**
 * ����һ��Ŀ¼�е������ļ�ʵ��
 */
DirectoryReader.prototype.readEntries = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var retVal = [];
        for (var i = 0; i < result.length; i++) {
            var entry = null;
            if (result[i].isDirectory) {
                entry = new DirectoryEntry();
            }
            else if (result[i].isFile) {
                entry = new FileEntry();
            }
            entry.isDirectory = result[i].isDirectory;
            entry.isFile = result[i].isFile;
            entry.name = result[i].name;
            entry.fullPath = result[i].fullPath;
            retVal.push(entry);
        }
        successCallback(retVal);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, null, "File", "readEntries", [this.path]);
};

module.exports = DirectoryReader;

});

define('xFace/extension/FileError', function(require, exports, module) {
/**
 * FileError
 */
function FileError(error) {
  this.code = error || null;
}

// File error codes
// Found in DOMException
FileError.NOT_FOUND_ERR = 1;
FileError.SECURITY_ERR = 2;
FileError.ABORT_ERR = 3;

// Added by File API specification
FileError.NOT_READABLE_ERR = 4;
FileError.ENCODING_ERR = 5;
FileError.NO_MODIFICATION_ALLOWED_ERR = 6;
FileError.INVALID_STATE_ERR = 7;
FileError.SYNTAX_ERR = 8;
FileError.INVALID_MODIFICATION_ERR = 9;
FileError.QUOTA_EXCEEDED_ERR = 10;
FileError.TYPE_MISMATCH_ERR = 11;
FileError.PATH_EXISTS_ERR = 12;

module.exports = FileError;

});

define("xFace/extension/FileReader", function(require, exports, module) {
var exec = require('xFace/exec'),
    FileError = require('xFace/extension/FileError'),
    ProgressEvent = require('xFace/extension/ProgressEvent');

var FileReader = function() {
    this.fileName = "";

    this.readyState = 0;

    this.result = null;

    this.error = null;

    // �¼����
    this.onloadstart = null;    // When the read starts.
    this.onprogress = null;     // While reading (and decoding) file or fileBlob data, and reporting partial file data (progess.loaded/progress.total)
    this.onload = null;         // When the read has successfully completed.
    this.onerror = null;        // When the read has failed (see errors).
    this.onloadend = null;      // When the request has completed (either in success or failure).
    this.onabort = null;        // When the read has been aborted. For instance, by invoking the abort() method.
};

// States
FileReader.EMPTY = 0;
FileReader.LOADING = 1;
FileReader.DONE = 2;

/**
 * ȡ����ȡ�ļ�
 */
FileReader.prototype.abort = function() {
    this.result = null;

    if (this.readyState == FileReader.DONE || this.readyState == FileReader.EMPTY) {
      return;
    }

    this.readyState = FileReader.DONE;

    if (typeof this.onabort === 'function') {
        this.onabort(new ProgressEvent('abort', {target:this}));
    }
    if (typeof this.onloadend === 'function') {
        this.onloadend(new ProgressEvent('loadend', {target:this}));
    }
};

/**
 * ��ȡtext����
 * @param file          Ҫ��ȡ���ļ�����
 * @param encoding      �����ʽ (see http://www.iana.org/assignments/character-sets)
 */
FileReader.prototype.readAsText = function(file, encoding) {
    this.fileName = '';
    if (typeof file.fullPath === 'undefined') {
        this.fileName = file;
    } else {
        this.fileName = file.fullPath;
    }

    if (this.readyState == FileReader.LOADING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    this.readyState = FileReader.LOADING;

    if (typeof this.onloadstart === "function") {
        this.onloadstart(new ProgressEvent("loadstart", {target:this}));
    }

    //Ĭ�ϵı����ʽΪUTF-8
    var enc = encoding ? encoding : "UTF-8";

    var me = this;

    exec(
        function(r) {
            if (me.readyState === FileReader.DONE) {
                return;
            }

            me.result = r;

            if (typeof me.onload === "function") {
                me.onload(new ProgressEvent("load", {target:me}));
            }

            me.readyState = FileReader.DONE;

            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },

        function(e) {
            if (me.readyState === FileReader.DONE) {
                return;
            }

            me.readyState = FileReader.DONE;

            me.result = null;

            me.error = new FileError(e);

            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {target:me}));
            }

            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },
        null, "File", "readAsText", [this.fileName, enc]);
};

/**
 * ��ȡ�ļ�������base64 encoded data url������
 * �������ݵĸ�ʽ:
 *      data:[<mediatype>][;base64],<data>
 *
 * @param file       Ҫ��ȡ���ļ�����
 */
FileReader.prototype.readAsDataURL = function(file) {
    this.fileName = "";
    if (typeof file.fullPath === "undefined") {
        this.fileName = file;
    } else {
        this.fileName = file.fullPath;
    }

    if (this.readyState == FileReader.LOADING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    this.readyState = FileReader.LOADING;

    if (typeof this.onloadstart === "function") {
        this.onloadstart(new ProgressEvent("loadstart", {target:this}));
    }

    var me = this;

    exec(
        function(r) {
            if (me.readyState === FileReader.DONE) {
                return;
            }

            me.readyState = FileReader.DONE;

            me.result = r;

            if (typeof me.onload === "function") {
                me.onload(new ProgressEvent("load", {target:me}));
            }

            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },
        function(e) {
            if (me.readyState === FileReader.DONE) {
                return;
            }

            me.readyState = FileReader.DONE;

            me.result = null;

            me.error = new FileError(e);

            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {target:me}));
            }

            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },
        null, "File", "readAsDataURL", [this.fileName]);
};

/**
 * ��ȡ�ļ������ض���������
 * @param file          Ҫ��ȡ���ļ�����
 */
FileReader.prototype.readAsBinaryString = function(file) {
    // TODO:Ŀǰ��֧��
    console.log('method "readAsBinaryString" is not supported at this time.');
};

/**
 * ��ȡ�ļ������ض���������
 * @param file          Ҫ��ȡ���ļ�����
 */
FileReader.prototype.readAsArrayBuffer = function(file) {
    // TODO:Ŀǰ��֧��
    console.log('This method is not supported at this time.');
};

module.exports = FileReader;

});

define('xFace/extension/FileWriter', function(require, exports, module) {
var exec = require('xFace/exec'),
    FileError = require('xFace/extension/FileError'),
    ProgressEvent = require('xFace/extension/ProgressEvent');

/**
 * ���캯��
 */
var FileWriter = function(file) {
    this.fileName = "";
    this.length = 0;
    if (file) {
        this.fileName = file.fullPath || file;
        this.length = file.size || 0;
    }
    // Ĭ�ϴӿ�ʼλ��д�ļ�
    this.position = 0;

    this.readyState = 0;

    this.result = null;

    this.error = null;

    // �¼����
    this.onwritestart = null;   // When writing starts
    this.onprogress = null;     // While writing the file, and reporting partial file data
    this.onwrite = null;        // When the write has successfully completed.
    this.onwriteend = null;     // When the request has completed (either in success or failure).
    this.onabort = null;        // When the write has been aborted. For instance, by invoking the abort() method.
    this.onerror = null;        // When the write has failed (see errors).
};

// ״̬
FileWriter.INIT = 0;
FileWriter.WRITING = 1;
FileWriter.DONE = 2;

/**
 * ȡ��д�ļ�
 */
FileWriter.prototype.abort = function() {
    if (this.readyState === FileWriter.DONE || this.readyState === FileWriter.INIT) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    this.error = new FileError(FileError.ABORT_ERR);

    this.readyState = FileWriter.DONE;

    if (typeof this.onabort === "function") {
        this.onabort(new ProgressEvent("abort", {"target":this}));
    }

    if (typeof this.onwriteend === "function") {
        this.onwriteend(new ProgressEvent("writeend", {"target":this}));
    }
};

/**
 * д�ļ�
 *
 * @param text Ҫд�������
 */
FileWriter.prototype.write = function(text) {
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }
    this.readyState = FileWriter.WRITING;

    var me = this;

    if (typeof me.onwritestart === "function") {
        me.onwritestart(new ProgressEvent("writestart", {"target":me}));
    }

    // д�ļ�
    exec(
        function(r) {
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            me.position += r;

            me.length = me.position;

            me.readyState = FileWriter.DONE;

            if (typeof me.onwrite === "function") {
                me.onwrite(new ProgressEvent("write", {"target":me}));
            }

            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        },
        function(e) {
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            me.readyState = FileWriter.DONE;

            me.error = new FileError(e);

            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {"target":me}));
            }

            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        }, null, "File", "write", [this.fileName, text, this.position]);
};

/**
 * �ӵ�ǰλ������ƶ��ļ�ָ��
 * ���offsetΪ��ֵ����Ӻ���ǰ�ƶ������offset�����ļ����ܴ�С���ļ�ָ�������ļ���ĩβ
 * @param offset �ļ�ָ��Ҫ�ƶ�����λ��.
 */
FileWriter.prototype.seek = function(offset) {
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    if (!offset) {
        return;
    }

    // �Ӻ���ǰ�ƶ�
    if (offset < 0) {
        this.position = Math.max(offset + this.length, 0);
    }
    // offset �����ļ����ܴ�С
    else if (offset > this.length) {
        this.position = this.length;
    }
    else {
        this.position = offset;
    }
};

/**
 * ����ļ�
 * @param size �����ʣ�µ��ļ���С
 */
FileWriter.prototype.truncate = function(size) {
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    this.readyState = FileWriter.WRITING;

    var me = this;

    if (typeof me.onwritestart === "function") {
        me.onwritestart(new ProgressEvent("writestart", {"target":this}));
    }

    exec(
        function(r) {
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            me.readyState = FileWriter.DONE;

            me.length = r;
            me.position = Math.min(me.position, r);

            if (typeof me.onwrite === "function") {
                me.onwrite(new ProgressEvent("write", {"target":me}));
            }

            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        },
        function(e) {
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            me.readyState = FileWriter.DONE;

            me.error = new FileError(e);

            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {"target":me}));
            }

            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        }, null, "File", "truncate", [this.fileName, size]);
};

module.exports = FileWriter;

});

define("xFace/extension/FileTransfer", function(require, exports, module) {
var exec = require('xFace/exec');

/**
 * @constructor
 */
var FileTransfer = function() {};

/**
 * ����һ���ļ���ָ����·��
 * @param source {String}         �ļ����ڵķ�����URL
 * @param target {String}         ��Ҫ���ص���ָ��·��
 * @param successCallback         �ɹ��ص�����
 * @param errorCallback           ʧ�ܻص�����
 */
FileTransfer.prototype.download = function(source, target, successCallback, errorCallback) {
    var win = function(result) {
        var entry = null;
        if (result.isDirectory) {
            entry = new DirectoryEntry();
        }
        else if (result.isFile) {
            entry = new FileEntry();
        }
        entry.isDirectory = result.isDirectory;
        entry.isFile = result.isFile;
        entry.name = result.name;
        entry.fullPath = result.fullPath;
        successCallback(entry);
    };
    exec(win, errorCallback, null, 'FileTransfer', 'download', [source, target]);
};

module.exports = FileTransfer;

});

define("xFace/extension/FileTransferError", function(require, exports, module) {
/**
 * FileTransferError
 * @constructor
 */
var FileTransferError = function(code) {
    this.code = code || null;
};

FileTransferError.FILE_NOT_FOUND_ERR = 1;
FileTransferError.INVALID_URL_ERR = 2;
FileTransferError.CONNECTION_ERR = 3;

module.exports = FileTransferError;

});

define("xFace/extension/Flags", function(require, exports, module) {
function Flags(create, exclusive) {
    this.create = create || false;
    this.exclusive = exclusive || false;
}

module.exports = Flags;

});

define("xFace/extension/LocalFileSystem", function(require, exports, module) {
var LocalFileSystem = function() {

};

LocalFileSystem.TEMPORARY = 0;  //��ʱ�ļ�
LocalFileSystem.PERSISTENT = 1; //�־��ļ�

module.exports = LocalFileSystem;

});

define("xFace/extension/FileSystem", function(require, exports, module) {
var DirectoryEntry = require('xFace/extension/DirectoryEntry');

/**
 * ���캯��
 * @param name ��ʶ�ļ�ϵͳ������ (readonly)
 * @param root �ļ�ϵͳ�ĸ�Ŀ¼ (readonly)
 */
var FileSystem = function(name, root) {
    this.name = name || null;
    if (root) {
        this.root = new DirectoryEntry(root.name, root.fullPath);
    }
};

module.exports = FileSystem;

});

define("xFace/extension/Metadata", function(require, exports, module) {
/**
 * {Date} modificationTime (readonly)
 */
var Metadata = function(time) {
    this.modificationTime = (typeof time != 'undefined'?new Date(time):null);
};

module.exports = Metadata;

});

define("xFace/extension/requestFileSystem", function(require, exports, module) {
var FileError = require('xFace/extension/FileError'),
    FileSystem = require('xFace/extension/FileSystem'),
    exec = require('xFace/exec');

/**
 * ����һ���ļ�ϵͳ���洢Ӧ������
 * @param type  �ļ�ϵͳ������
 * @param size  ָʾӦ�������Ĵ洢��С��bytes��
 * @param successCallback  �ɹ��Ļص�����
 * @param errorCallback    ʧ�ܵĻص�����
 */
var requestFileSystem = function(type, size, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };

    //TODO:Ŀǰֻ֧�������ļ����ͣ��Ժ���ܻ�������APPLICATION����������
    var LocalFileSystem_TEMPORARY = 0;  //��ʱ�ļ�
    var LocalFileSystem_PERSISTENT = 1; //�־��ļ�
    if (type < LocalFileSystem_TEMPORARY || type > LocalFileSystem_PERSISTENT) {
        fail(FileError.SYNTAX_ERR);
    } else {
        // ����ɹ�������FileSystem����
        var success = function(fileSystem) {
            if (fileSystem) {
                if (typeof successCallback === 'function') {

                    var result = new FileSystem(fileSystem.name, fileSystem.root);
                    successCallback(result);
                }
            }
            else {
                fail(FileError.NOT_FOUND_ERR);
            }
        };
        exec(success, fail, null, "File", "requestFileSystem", [type, size]);
    }
};

module.exports = requestFileSystem;

});

define("xFace/extension/resolveLocalFileSystemURI", function(require, exports, module) {
var DirectoryEntry = require('xFace/extension/DirectoryEntry'),
    FileEntry = require('xFace/extension/FileEntry'),
    exec = require('xFace/exec');

var resolveLocalFileSystemURI = function(uri, successCallback, errorCallback) {
    var fail = function(error) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(error));
        }
    };
    var success = function(entry) {
        var result;

        if (entry) {
            if (typeof successCallback === 'function') {
                result = (entry.isDirectory) ? new DirectoryEntry(entry.name, entry.fullPath) : new FileEntry(entry.name, entry.fullPath);
                try {
                    successCallback(result);
                }
                catch (e) {
                    console.log('Error invoking callback: ' + e);
                }
            }
        }
        else {
            fail(FileError.NOT_FOUND_ERR);
        }
    };

    exec(success, fail, null, "File", "resolveLocalFileSystemURI", [uri]);

};

module.exports = resolveLocalFileSystemURI;

});

define('xFace/extension/network', function(require, exports, module) {
var exec = require('xFace/exec'),
    xFace = require('xFace'),
    channel = require('xFace/channel');

var NetworkConnection = function () {
    this.type = null;
    this._firstRun = true;
    this._timer = null;
    this.timeout = 500;

    var me = this;

    channel.onxFaceReady.subscribeOnce(function() {
        me.getInfo(function (info) {
            me.type = info;
            if (info === "none") {
                // ����ڶ�ʱ���������Ȼ�� offline��������һ����ʱ�������� offline �¼�
                me._timer = setTimeout(function(){
                    xFace.fireDocumentEvent("offline");
                    me._timer = null;
                    }, me.timeout);
            } else {
                // �����һ�����ڴ����� offline �¼��������֮
                if (me._timer !== null) {
                    clearTimeout(me._timer);
                    me._timer = null;
                }
                xFace.fireDocumentEvent("online");
            }

            // ֻ fire һ��
            if (me._firstRun) {
                me._firstRun = false;
                channel.onxFaceConnectionReady.fire();
            }
        },
        function (e) {
            // ������ܻ�� network info������� fire deviceready �¼�
            if (me._firstRun) {
                me._firstRun = false;
                channel.onxFaceConnectionReady.fire();
            }
            console.log("Error initializing Network Connection: " + e);
        });
    });
};

/**
 * �������������Ϣ
 *
 * @param successCallback �����������ݿ���ʱ�Ļص�����
 * @param errorCallback   �ڻ�ȡ������������ʱ������Ļص���������ѡ��
 */
NetworkConnection.prototype.getInfo = function (successCallback, errorCallback) {
    exec(successCallback, errorCallback, null, "NetworkConnection", "getConnectionInfo", []);
};

module.exports = new NetworkConnection();

});

define("xFace/extension/Connection", function(require, exports, module) {
/**
 * ����״̬
 */
module.exports = {
        UNKNOWN: "unknown",
        ETHERNET: "ethernet",
        WIFI: "wifi",
        CELL_2G: "2g",
        CELL_3G: "3g",
        CELL_4G: "4g",
        NONE: "none"
};

});

define("xFace/extension/android/device", function(require, exports, module) {
var channel = require('xFace/channel'),
    exec = require('xFace/exec');

function Device() {
    this.platform = null;
    this.version = null;
    this.name = null;
    this.uuid = null;
    this.xFace = null;

    var me = this;

    channel.onxFaceReady.subscribeOnce(function() {
        me.getInfo(function(info) {
            me.platform = info.platform;
            me.version = info.version;
            me.name = info.name;
            me.uuid = info.uuid;
            me.xFace = info.xFace;
            channel.onxFaceInfoReady.fire();
        },function(e) {
            console.log("Error initializing xFace: " + e);
        });
    });
}

/**
 * ���Device�ϵ�����
 *
 * @param {Function} successCallback ��ȡdevice�ϵ����Գɹ�ʱ�Ļص�����
 * @param {Function} errorCallback ���device�ϵ�����ʧ��ʱ�Ļص�����
 */
Device.prototype.getInfo = function(successCallback, errorCallback) {
    if (typeof successCallback !== "function") {
        console.log("Device Error: successCallback is not a function");
        return;
    }

    if (errorCallback && (typeof errorCallback !== "function")) {
        console.log("Device Error: errorCallback is not a function");
        return;
    }

    exec(successCallback, errorCallback, null, "Device", "getDeviceInfo", []);
};

module.exports = new Device();
});

define("xFace/extension/Contact", function(require, exports, module) {
var exec = require('xFace/exec'),
    ContactError = require('xFace/extension/ContactError'),
    utils = require('xFace/utils');

/**
 * ��ԭʼ����ת��Ϊ���Ӷ���.
 * ��ǰ��Ӧ���� Data ��
 * @param  contact  ��Ҫ����ת���� contact ��Ϣ
 */
function convertIn(contact) {
    var value = contact.birthday;
    try {
      contact.birthday = new Date(parseFloat(value));
    } catch (exception){
      console.log("xFace Contact convertIn error: exception creating date.");
    }
    return contact;
};

/**
 * �����Ӷ���ת��Ϊԭʼ���ݣ��� convertIn ��Ӧ
 * ��ǰ��Ӧ���� Data ��
 * @param  contact  ��Ҫ����ת���� contact ��Ϣ
 */
function convertOut(contact) {
    var value = contact.birthday;
    if (value != null) {
        // ��� birthday ������һ�� Data ������������
        if (!(value instanceof Date)){
            try {
                value = new Date(value);
            } catch(exception){
                value = null;
            }
        }

        if (value instanceof Date){
            value = value.valueOf(); // ת��Ϊ milliseconds
        }

        contact.birthday = value;
    }
    return contact;
};

/**
 * ������ϵ�˰�������Ϣ
 * @constructor
 * @param {DOMString} id Ψһ��ʾ
 * @param {DOMString} displayName
 * @param {ContactName} name
 * @param {DOMString} nickname
 * @param {Array.<ContactField>} phoneNumbers �绰���������
 * @param {Array.<ContactField>} emails email��ַ����
 * @param {Array.<ContactAddress>} addresses ��ַ����
 * @param {Array.<ContactField>} ims ��ʱͨѶ�û��� id
 * @param {Array.<ContactOrganization>} organizations
 * @param {DOMString} birthday
 * @param {DOMString} note �û��Դ���ϵ�˵�ע��
 * @param {Array.<ContactField>} photos
 * @param {Array.<ContactField>} categories  ��Android ϵͳ�޶�Ӧ���ԣ�
 * @param {Array.<ContactField>} urls ��ϵ�˵���վ
 */
var Contact = function (id, displayName, name, nickname, phoneNumbers, emails, addresses,
    ims, organizations, birthday, note, photos, categories, urls) {
    this.id = id || null;
    this.rawId = null;
    this.displayName = displayName || null;
    this.name = name || null; // ContactName
    this.nickname = nickname || null;
    this.phoneNumbers = phoneNumbers || null; // ContactField[]
    this.emails = emails || null; // ContactField[]
    this.addresses = addresses || null; // ContactAddress[]
    this.ims = ims || null; // ContactField[]
    this.organizations = organizations || null; // ContactOrganization[]
    this.birthday = birthday || null;
    this.note = note || null;
    this.photos = photos || null; // ContactField[]
    this.categories = categories || null; // ContactField[]
    this.urls = urls || null; // ContactField[]
};

/**
 * ���豸�Ĵ洢�������ϵ��.
 */
Contact.prototype.remove = function(successCallback, errorCallback) {
    var fail = function(code) {
        errorCallback(new ContactError(code));
    };

    if (this.id === null) {
        fail(ContactError.UNKNOWN_ERROR);
    }
    else {
        exec(successCallback, fail, null, "Contacts", "remove", [this.id]);
    }
};

/**
 * ����һ����ϵ�˵����.
 * ���е� Id ������Ϊ null.
 * �����ɹ��󷵻ؿ����Ķ���
 */
Contact.prototype.clone = function() {
    var clonedContact = utils.clone(this);
    var i;
    clonedContact.id = null;
    clonedContact.rawId = null;
    // ����������������е� id
    if (clonedContact.phoneNumbers) {
        for (i = 0; i < clonedContact.phoneNumbers.length; i++) {
            clonedContact.phoneNumbers[i].id = null;
        }
    }
    if (clonedContact.emails) {
        for (i = 0; i < clonedContact.emails.length; i++) {
            clonedContact.emails[i].id = null;
        }
    }
    if (clonedContact.addresses) {
        for (i = 0; i < clonedContact.addresses.length; i++) {
            clonedContact.addresses[i].id = null;
        }
    }
    if (clonedContact.ims) {
        for (i = 0; i < clonedContact.ims.length; i++) {
            clonedContact.ims[i].id = null;
        }
    }
    if (clonedContact.organizations) {
        for (i = 0; i < clonedContact.organizations.length; i++) {
            clonedContact.organizations[i].id = null;
        }
    }
    if (clonedContact.categories) {
        for (i = 0; i < clonedContact.categories.length; i++) {
            clonedContact.categories[i].id = null;
        }
    }
    if (clonedContact.photos) {
        for (i = 0; i < clonedContact.photos.length; i++) {
            clonedContact.photos[i].id = null;
        }
    }
    if (clonedContact.urls) {
        for (i = 0; i < clonedContact.urls.length; i++) {
            clonedContact.urls[i].id = null;
        }
    }
    return clonedContact;
};

/**
 * ������ϵ����Ϣ���豸�洢��.
 * �洢�ɹ��󷵻ش���ϵ�˵� JSONObject��ʧ�ܺ�õ�������Ϣ
 */
Contact.prototype.save = function(successCallback, errorCallback) {
    var fail = function(code) {
        errorCallback(new ContactError(code));
    };

    var success = function(result) {
      if (result) {
          if (typeof successCallback === 'function') {
              var fullContact = require('xFace/extension/contacts').create(result);
              successCallback(convertIn(fullContact));
          }
      }
      else {
          fail(ContactError.UNKNOWN_ERROR);
      }
  };
    var dupContact = convertOut(utils.clone(this));
    exec(success, fail, null, "Contacts", "save", [dupContact]);
};

module.exports = Contact;

});

define("xFace/extension/contacts", function(require, exports, module) {
var exec = require('xFace/exec'),
    ContactError = require('xFace/extension/ContactError'),
    Contact = require('xFace/extension/Contact');

var contacts = {
    /**
     * ����һ����ϲ�ѯ��������ϵ������
     * @param fields ��Ҫ��ѯ����
     * @param successCallback
     * @param errorCallback
     * @param {ContactFindOptions} options Ӧ������ϵ�������е�ѡ��
     * @return һ����ϲ�ѯ��������ϵ������
     */
    find:function(fields, successCallback, errorCallback, options) {
        if (!successCallback) {
            throw new TypeError("You must specify a success callback for the find command.");
        }
        if (!fields || (fields instanceof Array && fields.length === 0)) {
            if (typeof errorCallback === "function") {
                errorCallback(new ContactError(ContactError.INVALID_ARGUMENT_ERROR));
            }
        } else {
            var win = function(result) {
                var cs = [];
                for (var i = 0, l = result.length; i < l; i++) {
                    cs.push(contacts.create(result[i]));
                }
                successCallback(cs);
            };
            exec(win, errorCallback, null, "Contacts", "search", [fields, options]);
        }
    },

    /**
     * ����һ���µ���ϵ�ˣ����˺��������䱣�����豸�洢�ϡ�
     * Ҫ�־ñ������豸�洢�ϣ��ɵ���contact.save()��
     * @param properties �����¶���������������
     * @returns һ���µ���ϵ�˶���
     */
    create:function(properties) {
        var i;
        var contact = new Contact();
        for (i in properties) {
            if (typeof contact[i] !== 'undefined' && properties.hasOwnProperty(i)) {
                contact[i] = properties[i];
            }
        }
        return contact;
    }
};

module.exports = contacts;

});

define("xFace/extension/ContactAddress", function(require, exports, module) {

/**
 * Contact address.
 * @constructor
 * @param id Ψһ��ʾ������ Native ������
 * @param pref Android ϵͳ�� Contact �в����¼�����ԣ������� Android Native ����ʽָ��Ϊ false
 * @param type ��ַ���ͣ����Ͱ�����home��work��other��custom��
 * @param formatted �ۺ� streetAddress��locality��region �� country �� ��ȫ��
 * @param streetAddress
 * @param locality
 * @param region
 * @param postalCode
 * @param country
 */
var ContactAddress = function(pref, type, formatted, streetAddress, locality, region, postalCode, country) {
    this.id = null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
    this.type = type || null;
    this.formatted = formatted || null;
    this.streetAddress = streetAddress || null;
    this.locality = locality || null;
    this.region = region || null;
    this.postalCode = postalCode || null;
    this.country = country || null;
};

module.exports = ContactAddress;

});

define("xFace/extension/ContactError", function(require, exports, module) {

var ContactError = function(err) {
    this.code = (typeof err != 'undefined' ? err : null);
};

/**
 * ������
 */
ContactError.UNKNOWN_ERROR = 0;
ContactError.INVALID_ARGUMENT_ERROR = 1;
ContactError.TIMEOUT_ERROR = 2;
ContactError.PENDING_OPERATION_ERROR = 3;
ContactError.IO_ERROR = 4;
ContactError.NOT_SUPPORTED_ERROR = 5;
ContactError.PERMISSION_DENIED_ERROR = 20;

module.exports = ContactError;

});

define("xFace/extension/ContactField", function(require, exports, module) {

/**
 * Contact field.
 * @constructor
 * @param id Ψһ��ʾ������ Native ������
 * @param type �绰�������ͣ����Ͱ�����home��work��moblie��
 * @param value ����ĵ绰����
 * @param pref Android ϵͳ�� Contact �в����¼�����ԣ������� Android Native ����ʽָ��Ϊ false
 */
var ContactField = function(type, value, pref) {
    this.id = null;
    this.type = type || null;
    this.value = value || null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
};

module.exports = ContactField;

});

define("xFace/extension/ContactFindOptions", function(require, exports, module) {

/**
 * ContactFindOptions.
 * @constructor
 * @param filter ����ָ����ѯʱ�� where �Ӿ䣬Ϊ��ʱ������������ϵ�˵���������
 * @param multiple ����ָ���Ƿ񷵻����������Ķ����ϵ����Ϣ��Ϊ true ʱ���ض����false ʱ����һ��
 */
var ContactFindOptions = function(filter, multiple) {
    this.filter = filter || '';
    this.multiple = (typeof multiple != 'undefined' ? multiple : false);
};

module.exports = ContactFindOptions;

});

define("xFace/extension/ContactName", function(require, exports, module) {

/**
 * Contact name.
 * @constructor
 * @param formatted �ۺ� familyName��givenName �� middle ���ȫ��
 * @param familyName
 * @param givenName
 * @param middle
 * @param prefix ��Ƶ�ǰ׺������ ���𾴵ġ����������ġ���
 * @param suffix ��Ƶĺ�׺������ ������������Ůʿ����
 */
var ContactName = function(formatted, familyName, givenName, middle, prefix, suffix) {
    this.formatted = formatted || null;
    this.familyName = familyName || null;
    this.givenName = givenName || null;
    this.middleName = middle || null;
    this.honorificPrefix = prefix || null;
    this.honorificSuffix = suffix || null;
};

module.exports = ContactName;

});

define("xFace/extension/ContactOrganization", function(require, exports, module) {

/**
 * Contact organization.
 * @constructor
 * @param id Ψһ��ʾ������ Native ������
 * @param pref Android ϵͳ�� Contact �в����¼�����ԣ������� Android Native ����ʽָ��Ϊ false
 * @param type �������ͣ����Ͱ�����work��other��custom��
 * @param name ��������
 * @param department ��������
 * @param title ְλ����
 */
var ContactOrganization = function(pref, type, name, dept, title) {
    this.id = null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
    this.type = type || null;
    this.name = name || null;
    this.department = dept || null;
    this.title = title || null;
};

module.exports = ContactOrganization;

});

define("xFace/extension/Telephony",function(require,exports,module) {
var exec = require('xFace/exec'),
    CallRecord = require('xFace/extension/CallRecord');
/**
 * Telephony�Ĺ��캯��
 */
var Telephony = function(){
}

/**
 * ɾ��ָ��ͨ����¼���͵�����ͨ����¼
 *
 * @param callRecordType ͨ����¼���� �� CallRecordType�ж����
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.deleteAllCallRecords = function(callRecordType,successCallback,errorCallback){
    exec(successCallback, errorCallback, null, "Telephony", "deleteAllCallRecords", [callRecordType]);
}

/**
 * ɾ��ָ��ͨ����¼���ͺ�ָ��id��ͨ����¼
 *
 * @param callRecordType ͨ����¼���� �� CallRecordType�ж����
 * @param id ͨ����¼��id��
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.deleteCallRecord = function(callRecordType,id,successCallback,errorCallback){
    exec(successCallback, errorCallback, null, "Telephony", "deleteCallRecord", [callRecordType,id]);
}

/**
 * ��ȡָ��ͨ����¼���ͺ�id��ͨ����¼
 *
 * @param callRecordType ͨ����¼���� �� CallRecordType�ж����
 * @param index ͨ����¼������
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.getCallRecord = function(callRecordType,index,successCallback,errorCallback){
    var success = function(result){
        var callRecord = new CallRecord(result.callRecordAddress,result.callRecordId,result.callRecordName,
                                        result.callRecordType,result.durationSeconds,new Date(result.startTime));
        successCallback(callRecord);
    }
    exec(success, errorCallback, null, "Telephony", "getCallRecord", [callRecordType,index]);
}

/**
 * ���մ�ƥ���ͨ����¼����ָ����Χ�ڵ�ͨ����¼
 *
 * @param comparisonCallRecord ��ƥ���ͨ����¼����
 * @param startIndex ��ʼλ������
 * @param endIndex ����λ������
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.findCallRecords = function(comparisonCallRecord,startIndex,endIndex,successCallback,errorCallback){
    if(startIndex < 0 && endIndex < 0){
        throw "ivalid_parameter";
    }
    var comparison = {callRecordAddress:"*",callRecordId:"",callRecordName:"*",callRecordType:"",durationSeconds:-1,startTime:-1};
    if(null != comparisonCallRecord){
        comparison.callRecordAddress = comparisonCallRecord.callRecordAddress == null ? "" : comparisonCallRecord.callRecordAddress;
        comparison.callRecordId = comparisonCallRecord.callRecordId == null ? "" : comparisonCallRecord.callRecordId;
        comparison.callRecordName = comparisonCallRecord.callRecordName == null ? "" : comparisonCallRecord.callRecordName;
        comparison.callRecordType = comparisonCallRecord.callRecordType == null ? "" : comparisonCallRecord.callRecordType;
        comparison.durationSeconds = comparisonCallRecord.durationSeconds == null ? -1 : comparisonCallRecord.durationSeconds;//������������򽫸���ֵ��Ϊ-1,java�����Ƿ�Ϊ-1��-1��ʾ���պ��Ը���
        comparison.startTime = comparisonCallRecord.startTime == null ? -1 : (comparisonCallRecord.startTime.getTime());//������������򽫸���ֵ��Ϊ-1,java�����Ƿ�Ϊ-1��-1��ʾ���պ��Ը���
    }
    var success = function(result){
        var len = result.length;
        var callRecordArr = new Array();
        for(var i = 0 ; i < len ; i++){
            var callRecord = new CallRecord(result[i].callRecordAddress,result[i].callRecordId,result[i].callRecordName,
                                        result[i].callRecordType,result[i].durationSeconds,new Date(result[i].startTime));
            callRecordArr.push(callRecord);
        }
        successCallback(callRecordArr);
    }
    exec(success, errorCallback, null, "Telephony", "findCallRecords", [comparison,startIndex,endIndex]);
}

/**
 * ��ȡָ��ͨ����¼���͵�ͨ����¼����
 *
 * @param callRecordType ͨ����¼���� �� CallRecordType�ж����
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.getCallRecordCount = function(callRecordType,successCallback,errorCallback){
    var success = function(result){
        successCallback(result);
    }
    exec(success, errorCallback, null, "Telephony", "getCallRecordCount", [callRecordType]);
}

/**
 * ����绰
 *
 * @param phoneNumber �绰����
 * @param successCallback �ɹ��Ļص�����
 * @param errorCallback ʧ�ܻص�����
 */
Telephony.prototype.initiateVoiceCall = function(phoneNumber,successCallback,errorCallback){
    exec(successCallback, errorCallback, null, "Telephony", "initiateVoiceCall", [phoneNumber]);
};
module.exports = new Telephony();
});

define("xFace/extension/CallRecord",function(require,exports,module) {
var CallRecord = function(callRecordAddress,callRecordId,callRecordName,callRecordType,durationSeconds,startTime){
    this.callRecordAddress = callRecordAddress || null;
    this.callRecordId = callRecordId || null;
    this.callRecordName = callRecordName || null;
    this.callRecordType = callRecordType || null;
    this.durationSeconds = durationSeconds || null;
    this.startTime = startTime || null;
}
module.exports = CallRecord;
});

define("xFace/extension/CallRecordTypes",function(require,exports,module) {
var CallRecordTypes = {
    RECEIVED:"RECEIVED",
    OUTGOING:"OUTGOING",
    MISSED:"MISSED"
}

module.exports = CallRecordTypes;
});

define("xFace/extension/Message", function(require, exports, module) {

/**
 * Message.
 * @constructor
 * @param messageId Ψһ��ʾ������ Native ������
 * @param subject ��Ϣ�ı���
 * @param body ��Ϣ������
 * @param destinationAddresses Ŀ�ĵ�ַ
 * @param messageType ��Ϣ�����ͣ����ţ����ţ�Email�ȵȣ�
 * @param date ��Ϣ������
 * @param isRead ��Ϣ�Ƿ��Ѷ�
 */
var Message = function(messageId, subject, body, destinationAddresses, messageType, date, isRead) {
    this.messageId = messageId || null;
    this.subject = subject || null;
    this.body = body || null;
    this.destinationAddresses = destinationAddresses || null;
    this.messageType = messageType || null;
    this.date = date || null;
    this.isRead = isRead || null;
};

module.exports = Message;

});

define("xFace/extension/MessageFolderTypes", function(require, exports, module) {
var MessageFolderTypes = function() {
};

MessageFolderTypes.DRAFTS = "DRAFT";  //�ݸ���
MessageFolderTypes.INBOX = "INBOX";   //�ռ���
MessageFolderTypes.OUTBOX = "OUTBOX"; //������
MessageFolderTypes.SENTBOX = "SENT";  //��������Ϣ

module.exports = MessageFolderTypes;

});

define("xFace/extension/MessageTypes", function(require, exports, module) {
var MessageTypes = function() {
};

MessageTypes.EmailMessage = "Email";
MessageTypes.MMSMessage = "MMS";
MessageTypes.SMSMessage = "SMS";

module.exports = MessageTypes;

});

define("xFace/extension/Messaging", function(require, exports, module) {
var exec = require('xFace/exec'),
    Message = require('xFace/extension/Message');

var Messaging = function() {
};

/**
 * ������Ϣ.
 * @param messageType     ��Ϣ���ͣ���MMS,SMS,Email��
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 */
Messaging.prototype.createMessage = function(messageType, successCallback, errorCallback) {
    //TODO:����messageType������ͬ���͵���Ϣ��Ŀǰֻ�����˶���Ϣ
    var result = new Message();
    result.messageType = messageType;
    successCallback(result);
}

/**
 * ���Ͷ���.
 * @param message         Ҫ���͵���Ϣ����
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 */
Messaging.prototype.sendMessage = function(message, successCallback, errorCallback){
    exec(successCallback, errorCallback, null, "Messaging", "sendMessage", [message.messageType, message.destinationAddresses, message.body]);
};

/**
 * ��ȡָ����Ϣ�ļ��еĶ�������.
 * @param messageType     ��Ϣ���ͣ���MMS,SMS,Email��
 * @param folderType      �ļ������ͣ����ռ��䣬�����䣬��������Ϣ���ݸ��䣩
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 * ע���ýӿڲ�֧�ֶ�ȡSIM������Ϣ
 */
Messaging.prototype.getQuantities = function(messageType, folderType, successCallback, errorCallback) {
    exec(
        function(result) {
            successCallback(result);
        },
        errorCallback, null, "Messaging", "getQuantities", [messageType, folderType]);
};

/**
 * ��ȡָ������Ϣ.
 * @param messageType     ��Ϣ���ͣ���MMS,SMS,Email��
 * @param folderType      �ļ������ͣ����ռ��䣬�����䣬��������Ϣ���ݸ��䣩
 * @param index           Ҫ��ȡ�Ķ�������
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 * ע���ýӿڲ�֧�ֻ�ȡSIM������Ϣ
 */
Messaging.prototype.getMessage = function(messageType, folderType, index, successCallback, errorCallback) {
     var win = typeof successCallback !== 'function' ? null : function(result) {
        var message = new Message(result.messageId, result.subject, result.body, result.destinationAddresses,
                            result.messageType, new Date(result.date), result.isRead);
        successCallback(message);
    };
    exec(win, errorCallback, null, "Messaging", "getMessage", [messageType, folderType, index]);
};

/**
 * ��ȡĳ���ļ����е�������Ϣ.
 * @param messageType     ��Ϣ���ͣ���MMS,SMS,Email��
 * @param folderType      �ļ������ͣ����ռ��䣬�����䣬��������Ϣ���ݸ��䣩
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 * ע���ýӿڲ�֧�ֶ�ȡSIM������Ϣ
 */
Messaging.prototype.getAllMessages = function(messageType, folderType, successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var retVal = [];
        for (var i = 0; i < result.length; i++) {
            var message = new Message(result[i].messageId, result[i].subject, result[i].body, result[i].destinationAddresses,
                                result[i].messageType, new Date(result[i].date), result[i].isRead);
            retVal.push(message);
        }
        successCallback(retVal);
    };
    exec(win, errorCallback, null, "Messaging", "getAllMessages", [messageType, folderType]);
};

/**
 * ����ĳ���ļ�����ָ������Ϣ.
 * @param comparisonMsg   Ҫ���ҵ���Ϣ
 * @param folderType      �ļ������ͣ����ռ��䣬�����䣬��������Ϣ���ݸ��䣩
 * @param startIndex      ��ʼ����
 * @param endIndex        ��������
 * @param successCallback �ɹ��ص�����
 * @param errorCallback   ʧ�ܻص�����
 * ע���ýӿڲ�֧�ֶ�ȡSIM������Ϣ
 */
Messaging.prototype.findMessages = function(comparisonMsg, folderType, startIndex, endIndex, successCallback, errorCallback) {
    var comparison = {messageId:"", subject:"", destinationAddresses:"", body:"", isRead:-1};
    if(null != comparisonMsg){
        comparison.messageId = comparisonMsg.messageId || "";
        comparison.subject = comparisonMsg.subject || "";
        comparison.destinationAddresses = comparisonMsg.destinationAddresses || "";
        comparison.body = comparisonMsg.body || "";
        if(null == comparisonMsg.isRead) {
            comparison.isRead = -1;
        }
        else if(comparisonMsg.isRead) {
            comparison.isRead = 1;
        }
        else {
            comparison.isRead = 0;
        }
    }
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var retVal = [];
        for(var i = 0 ; i < result.length ; i++){
            var message = new Message(result[i].messageId, result[i].subject, result[i].body, result[i].destinationAddresses, result[i].messageType,
                                        new Date(result[i].date), result[i].isRead);
            retVal.push(message);
        }
        successCallback(retVal);
    }
    exec(win, errorCallback, null, "Messaging", "findMessages", [comparison, folderType, startIndex, endIndex]);
}

module.exports = new Messaging();

});

define("xFace/extension/CompassError", function(require, exports, module) {
var CompassError = function(err) {
    this.code = (err !== undefined ? err : null);
};

CompassError.COMPASS_INTERNAL_ERR = 0;
CompassError.COMPASS_NOT_SUPPORTED = 20;

module.exports = CompassError;

});

define("xFace/extension/CompassHeading", function(require, exports, module) {
var CompassHeading = function(magneticHeading, trueHeading, headingAccuracy, timestamp) {
  this.magneticHeading = (magneticHeading !== undefined ? magneticHeading : null);
  this.trueHeading = (trueHeading !== undefined ? trueHeading : null);
  this.headingAccuracy = (headingAccuracy !== undefined ? headingAccuracy : null);
  this.timestamp = (timestamp !== undefined ? timestamp : new Date().getTime());
};

module.exports = CompassHeading;

});

define("xFace/extension/compass", function(require, exports, module) {
var exec = require('xFace/exec'),
    utils = require('xFace/utils'),
    CompassHeading = require('xFace/extension/CompassHeading'),
    CompassError = require('xFace/extension/CompassError'),
    timers = {},
    compass = {
        /**
         * ��ȡ��ǰ��heading
         * @param successCallback �ɹ��ص�����
         * @param errorCallback   ʧ�ܻص�����
         * @param options         ���heading��ѡ�����ָ��frequency
         */
        getCurrentHeading:function(successCallback, errorCallback, options) {
            if (typeof successCallback !== "function") {
              console.log("Compass Error: successCallback is not a function");
              return;
            }

            if (errorCallback && (typeof errorCallback !== "function")) {
              console.log("Compass Error: errorCallback is not a function");
              return;
            }

            var win = function(result) {
                var ch = new CompassHeading(result.magneticHeading, result.trueHeading, result.headingAccuracy, result.timestamp);
                successCallback(ch);
            };
            var fail = function(code) {
                var ce = new CompassError(code);
                errorCallback(ce);
            }

            exec(win, fail, null, "Compass", "getCurrentHeading", [options]);
        },

        /**
         * ����heading
         * @param successCallback �ɹ��ص�����
         * @param errorCallback   ʧ�ܻص�����
         * @param options         ���ڼ���heading��ѡ�����ָ��frequency����δָ������Ĭ�ϵ�100msec
         * @return ����watch id
         */
        watchHeading:function(successCallback, errorCallback, options) {
            // Ĭ�ϵ�frequency(100 msec)
            var frequency = (options !== undefined && options.frequency !== undefined) ? options.frequency : 100;

            if (typeof successCallback !== "function") {
              console.log("Compass Error: successCallback is not a function");
              return;
            }

            if (errorCallback && (typeof errorCallback !== "function")) {
              console.log("Compass Error: errorCallback is not a function");
              return;
            }

            var id = utils.createUUID();

            timers[id] = window.setInterval(function() {
                compass.getCurrentHeading(successCallback, errorCallback);
            }, frequency);

            return id;
        },

        /**
         * ȡ����idָ���ļ�����
         * @param id ��watchHeading���ص�watch id
         */
        clearWatch:function(id) {
            // Stop javascript timer & remove from timer list
            if (id && timers[id]) {
                clearInterval(timers[id]);
                delete timers[id];
            }
        }
    };

module.exports = compass;

});

define("xFace/extension/android/app", function(require, exports, module) {
var exec = require('xFace/exec');
var app = function() {
};

app.prototype.exitApp = function(){
//closeApplication
exec(null, null, null, "App", "exitApp", []);
};

/**
 * ����ϵͳ�Դ����������url
 * @param url Ҫ�򿪵�url
 * @param success �ɹ��ص�����
 * @param error ʧ�ܻص�����
 * */
app.prototype.openUrl = function(url,success,error){
	exec(success,error,null,"App","openUrl",[url]);
}
module.exports = new app();

});

define("xFace/extension/Acceleration", function(require, exports, module) {
var Acceleration = function(x, y, z, timestamp) {
  this.x = x;
  this.y = y;
  this.z = z;
  this.timestamp = timestamp || (new Date()).getTime();
};

module.exports = Acceleration;

});

define("xFace/extension/accelerometer", function(require, exports, module) {
var utils = require("xFace/utils"),
    exec = require("xFace/exec");

var timers = {};

var accelerometer = {
    /**
     * ��õ�ǰ��Acceleration
     *
     * @param successCallback �ɹ��ص�����
     * @param errorCallback   ʧ�ܻص�����(��ѡ)
     * @param options         ���accelerometer��ѡ����糬ʱʱ��(��ѡ)
     */
    getCurrentAcceleration: function(successCallback, errorCallback, options) {
        // successCallback required
        if (typeof successCallback !== "function") {
            console.log("Accelerometer Error: successCallback is not a function");
            return;
        }
        // errorCallback optional
        if (errorCallback && (typeof errorCallback !== "function")) {
            console.log("Accelerometer Error: errorCallback is not a function");
            return;
        }
        exec(successCallback, errorCallback, null, "Accelerometer", "getCurrentAcceleration", []);
    },

   /**
     * ����Acceleration
     *
     * @param successCallback �ɹ��ص�����
     * @param errorCallback   ʧ�ܻص�����(��ѡ)
     * @param options         ����Acceleration��ѡ�����frequency(��ѡ����)
     * @return String         ����Ψһ��watchId
     */
    watchAcceleration: function(successCallback, errorCallback, options) {

        //��������δָ��frequency����ʹ��Ĭ�ϵ�10sec��Ϊfrequency
        var frequency = (options !== undefined && options.frequency !== undefined)? options.frequency : 10000;

        if (typeof successCallback !== "function") {
            console.log("Accelerometer Error: successCallback is not a function");
            return;
        }

        if (errorCallback && (typeof errorCallback !== "function")) {
            console.log("Accelerometer Error: errorCallback is not a function");
            return;
        }

        //��֤timeoutָ����ʱ��Ҫ����frequency����10sec
        //��Ϊ��timeoutС��frequency����sensor�ᷴ���Ŀ��أ���ɶԵ������˷�
        exec(
            function(timeout) {
                if (timeout < (frequency + 10000)) {
                    exec(null, null, null, "Accelerometer", "setTimeout", [frequency + 10000]);
                }
            },
            function(e) { }, null, "Accelerometer", "getTimeout", []);

        var id = utils.createUUID();
        timers[id] = window.setInterval(function() {
            exec(successCallback, errorCallback, null, "Accelerometer", "getCurrentAcceleration", []);
        }, frequency);

        return id;
    },

    /**
     * ȡ����idָ���ļ�����
     *
     * @param id   ��watchAcceleration���ص�watchId
     */
    clearWatch: function(id) {
        if (id && timers[id] !== undefined) {
            window.clearInterval(timers[id]);
            delete timers[id];
        }
    }
};

module.exports = accelerometer;

});

define("xFace/extension/UPPCardlessTrans", function(require, exports, module) {
var exec = require('xFace/exec');

/**
 * @���캯��
 */
var UPPCardlessTrans = function() {};

/**
* ���ù�Կ.
* �ɹ�ͨ��secessCallback����0,ʧ��ͨ��errorCallback���ش�����
* @param publicMod  {String} ��Կģ��
* @param publicExmod{String} ��Կָ��
* @param successCallback    �ɹ��ص�����
* @param errorCallback      ʧ�ܻص�����
*/
UPPCardlessTrans.prototype.setPublicKey = function(successCallback, errorCallback, publicMod, publicExmod) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'setPublicKey',[publicMod, publicExmod]);
};

/**
 * ���öԳ���Կ.
 * �ɹ�ͨ��secessCallback����0,ʧ��ͨ��errorCallback���ش�����
 * @param sessionID  {String} �Գ���Կ
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.setSessionID = function(successCallback, errorCallback, sessionID) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'setSessionID',[sessionID]);
};

/**
 * �ؼ��������ݽ���.
 * �ɹ�ͨ��secessCallback����0,ʧ��ͨ��errorCallback���ش�����
 * @param sectionStr  {String} �ؼ���������
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.decryptSection = function(successCallback, errorCallback, sectionStr) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'decryptSection',[sectionStr]);
};

/**
 * ����֧���ĻỰ��ʼ�����Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param paaStr      {String} �û�������ϢPAA
 * @param sysProvide  {String} ϵͳ֧�ַ�
 * @param mobileType  {String} �ƶ��ն��ͺ�
 * @param mobileOS    {String} �ƶ��ն�OS��Ϣ
 * @param mobileIMEI  {String} �ƶ��豸���к�IMEI
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.purchaseInit = function(successCallback, errorCallback, paaStr, sysProvide, mobileType, mobileOS, mobileIMEI) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'purchaseInit',[paaStr, sysProvide, mobileType, mobileOS, mobileIMEI]);
};

/**
 * ��ȡ���п�֧���б����Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.getSupportBankList = function(successCallback, errorCallback) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'getSupportBankList',[]);
};

/**
 * ��ȡ������֤�뱨�Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param phoneNum    {String} �ֻ�����
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.getSMSIdentifyingCode = function(successCallback, errorCallback, phoneNum) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'getSMSIdentifyingCode',[phoneNum]);
};

/**
 * ��֤������֤�뱨�Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param phoneNum          {String} �ֻ�����
 * @param identifyingCode   {String} ������֤��
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.verifySMSIdentifyingCode = function(successCallback, errorCallback, phoneNum, identifyingCode) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'verifySMSIdentifyingCode',[phoneNum, identifyingCode]);
};

/**
 * ���п�������Ϣ��ѯ���Ľӿڣ���ͨ�����Ż�Ψһ��ʶ���ѯ.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param bankCardNum   {String} ���п���
 * @param uniqueID      {String} �޿�Ψһ��ʶ��
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.queryTransInfo = function(successCallback, errorCallback, bankCardNum, uniqueID) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'queryTransInfo',[bankCardNum, uniqueID]);
};

/**
 * ���п���Ϣ��ѯ���Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param bankCardNum   {String} ���п���
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.queryBankCardInfo = function(successCallback, errorCallback, bankCardNum) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'queryBankCardInfo',[bankCardNum]);
};

/**
 * ���ѱ��Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param bankCardNum   {String} ���˺ţ����п��Ż����ÿ���
 * @param uniqueID      {String} �޿�֧��Ψһ��ʶ��
 * @param phoneNum      {String} �ֻ�����
 * @param password      {String} ���п�����
 * @param CVN2          {String} ���ÿ�CVN2
 * @param expireDate    {String} ���ÿ���Ч��
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.purchase = function(successCallback, errorCallback, bankCardNum, uniqueID, phoneNum, password, CVN2, expireDate) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'purchase',[bankCardNum, uniqueID, phoneNum, password, CVN2, expireDate]);
};

/**
 * ���ڵ�½��֤�ĻỰ��ʼ�����Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param laaStr        {String} ��֤��Ϣlaa�ַ���
 * @param sysProvide    {String} ϵͳ֧�ַ�
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.loginInit = function(successCallback, errorCallback, laaStr, sysProvide) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'loginInit',[laaStr, sysProvide]);
};

/**
 * �޿�����ѯ���Ľӿ�.
 * �ɹ�ͨ��secessCallback������װ�õı���,ʧ��ͨ��errorCallback���ش�����
 * @param bankCardNum   {String} ���˺ţ����п��Ż����ÿ���
 * @param phoneNum      {String} �ֻ�����
 * @param password      {String} ���п�����
 * @param CVN2          {String} ���ÿ�CVN2
 * @param expireDate    {String} ���ÿ���Ч��
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
UPPCardlessTrans.prototype.balance = function(successCallback, errorCallback, bankCardNum, phoneNum, password, CVN2, expireDate) {
    exec(successCallback, errorCallback, null, 'UPPCardlessTrans', 'balance',[bankCardNum, phoneNum, password, CVN2, expireDate]);
};

 module.exports = new UPPCardlessTrans();

});

define("xFace/extension/HttpTransfer", function(require, exports, module) {
  var exec = require('xFace/exec');

/**
 * @���캯��
 */
  var HttpTransfer = function() {};

/**
 * Http�����շ�
 * @param dataStr   {String} ��Ҫ���͵������ַ���
 * @param host      {String} Ŀ���ַ
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
HttpTransfer.prototype.httpPkgTransfer = function(successCallback, errorCallback, dataStr, host)
{
    exec(successCallback, errorCallback, null, 'HttpTransfer', 'httpPkgTransfer', [dataStr, host]);
};

/**
 * ���ó�ʱʱ��
 * @param maxTime   {String} ��Ҫ���͵������ַ���
 * @param successCallback    �ɹ��ص�����
 * @param errorCallback      ʧ�ܻص�����
 */
HttpTransfer.prototype.setMaxTime = function(successCallback, errorCallback, maxTime)
{
    exec(successCallback, errorCallback, null, 'HttpTransfer', 'setMaxTime', [maxTime]);
};

  module.exports = new HttpTransfer();

});


define("xFace/extension/battery", function(require, exports, module) {
var xFace = require('xFace') ,
    exec = require('xFace/exec');

function handlers() {
  return battery.channels.batterystatus.numHandlers +
         battery.channels.batterylow.numHandlers +
         battery.channels.batterycritical.numHandlers;
}

var Battery = function() {
    this._level = null;
    this._isPlugged = null;
    // Create new event handlers on the window (returns a channel instance)
    var subscriptionEvents = {
      onSubscribe:this.onSubscribe,
      onUnsubscribe:this.onUnsubscribe
    };
    this.channels = {
      batterystatus:xFace.addWindowEventHandler("batterystatus", subscriptionEvents),
      batterylow:xFace.addWindowEventHandler("batterylow", subscriptionEvents),
      batterycritical:xFace.addWindowEventHandler("batterycritical", subscriptionEvents)
    };
};

/**
 * Event handlers for when callbacks get registered for the battery.
 * Keep track of how many handlers we have so we can start and stop the native battery listener
 * appropriately (and hopefully save on battery life!).
 */
Battery.prototype.onSubscribe = function() {
  var me = battery;
  // If we just registered the first handler, make sure native listener is started.
  if (handlers() === 1) {
    exec(me._status, me._error, null, "Battery", "start", []);
  }
};

Battery.prototype.onUnsubscribe = function() {
  var me = battery;

  // If we just unregistered the last handler, make sure native listener is stopped.
  if (handlers() === 0) {
      exec(null, null, null, "Battery", "stop", []);
  }
};

/**
 * ���״̬�ɹ��ص�����
 *
 * @param {Object} info         keys: level, isPlugged
 */
Battery.prototype._status = function(info) {
    if (info) {
        var me = battery;
        var level = info.level;
        if (me._level !== level || me._isPlugged !== info.isPlugged) {
            // Fire batterystatus event
            xFace.fireWindowEvent("batterystatus", info);

            // Fire low battery event
            if (level === 20 || level === 5) {
                if (level === 20) {
                    xFace.fireWindowEvent("batterylow", info);
                }
                else {
                    xFace.fireWindowEvent("batterycritical", info);
                }
            }
        }
        me._level = level;
        me._isPlugged = info.isPlugged;
    }
};

/**
 * ���״̬�Ĵ���ص�����
 */
Battery.prototype._error = function(e) {
    console.log("Error initializing Battery: " + e);
};

var battery = new Battery();

module.exports = battery;
});

define("xFace/extension/Notification", function(require, exports, module) {
    var exec = require('xFace/exec');
    var notification = function() {};

notification.prototype.alert = function(message, alertCallback, title, buttonLabel){
    var _title = (title || "Alert");
    var _buttonLabel = (buttonLabel || "OK");
    exec(alertCallback, null, null, "Notification", "alert", [message, _title, _buttonLabel]);
};

notification.prototype.confirm = function(message, alertCallback, title, buttonLabels){
    var _title = (title || "Confirm");
    var _buttonLabels = (buttonLabels || "OK,Cancel");
    exec(alertCallback, null, null, "Notification", "confirm", [message, _title, _buttonLabels]);
};

/**
 * �豸������������.
 * �� Android ��, notification �����Ĳ��Ŵ������ⲿ����Ĳ��� "count" ָ��.
 *
 * @param {Integer} count       ���������ظ�����.
 */
notification.prototype.beep = function(count) {
    exec(null, null, null, "Notification", "beep", [count]);
};

/**
 * �豸����.
 *
 * @param {Integer} mills       �𶯵ĺ�����.
 */
notification.prototype.vibrate = function(mills) {
    exec(null, null, null, "Notification", "vibrate", [mills]);
};

module.exports = new notification();

});

define('xFace/extension/android/console', function(require, exports, module) {
var exec = require('xFace/exec');

/**
 * This class provides access to the debugging console.
 * @constructor
 */
var DebugConsole = function() {
    this.winConsole = window.console;
    this.logLevel = DebugConsole.INFO_LEVEL;
};

// from most verbose, to least verbose
DebugConsole.ALL_LEVEL    = 1; // same as first level
DebugConsole.INFO_LEVEL   = 1;
DebugConsole.WARN_LEVEL   = 2;
DebugConsole.ERROR_LEVEL  = 4;
DebugConsole.NONE_LEVEL   = 8;

DebugConsole.prototype.setLevel = function(level) {
    this.logLevel = level;
};

var stringify = function(message) {
    try{
       if(typeof message === "object" && JSON && JSON.stringify) {
           return JSON.stringify(message);
       } else {
           return message.toString();
       }
    } catch (e) {
       return e.toString;
    }
}

/**
 * Print a normal log message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.log = function(message) {
    if (this.logLevel <= DebugConsole.INFO_LEVEL) {
        exec(null, null, null, 'Console', 'log', [ stringify(message), 'INFO' ]);
    } else {
       this.winConsole.log(message);
    }
 };

/**
 * Print a warning message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.warn = function(message) {
    if (this.logLevel <= DebugConsole.WARN_LEVEL)
        exec(null, null, null, 'Console', 'log', [ stringify(message), 'WARN' ]);
    else
        this.winConsole.error(message);
};

/**
 * Print an error message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.error = function(message) {
    if (this.logLevel <= DebugConsole.ERROR_LEVEL)
        exec(null, null, null, 'Console', 'log', [ stringify(message), 'ERROR' ]);
    else
        this.winConsole.error(message);
};

module.exports = new DebugConsole();

});

define("xFace/extension/CaptureAudioOptions", function(require, exports, module) {

var CaptureAudioOptions = function(){
    //�ڵ����ɼ������ڼ��ܹ���¼����Ƶ�����������ֵ�������趨Ϊ���ڵ���1��Ĭ��ֵΪ1��
    this.limit = 1;
    //һ����Ƶ�������ʱ�䣬��λΪ�롣(androidƽ̨��֧��)
    this.duration = 0;
    //ѡ������Ƶģʽ�������趨Ϊcapture.supportedAudioModesö���е�ֵ��(androidƽ̨��֧��)
    this.mode = null;
};

module.exports = CaptureAudioOptions;

});

define("xFace/extension/CaptureError", function(require, exports, module) {

var CaptureError = function(c) {
   this.code = c || null;
};

// ����ͷ���߶����ɼ�ͼƬ������ʧ�ܡ�
CaptureError.CAPTURE_INTERNAL_ERR = 0;
// ����ͷ������Ƶ�ɼ��������ڴ�����Ĳɼ�����
CaptureError.CAPTURE_APPLICATION_BUSY = 1;
// �Ƿ���API����(Limit ������ֵС��1)��
CaptureError.CAPTURE_INVALID_ARGUMENT = 2;
// �ڲɼ����κ���Ϣ֮ǰ�û��˳�������ͷ������Ƶ�ɼ�����
CaptureError.CAPTURE_NO_MEDIA_FILES = 3;
// �ɼ���Ϣ�������ǲ�֧�ֵ�����
CaptureError.CAPTURE_NOT_SUPPORTED = 20;

module.exports = CaptureError;

});

define("xFace/extension/CaptureImageOptions", function(require, exports, module) {
var CaptureImageOptions = function(){
    // �ڵ����ɼ������ڼ��ܹ��ɼ���ͼ���������ֵ�������趨Ϊ���ڵ���1��Ĭ��ֵΪ1����
    this.limit = 1;
    // ѡ����ͼ��ģʽ�������趨Ϊcapture.supportedImageModesö���е�ֵ��(androidƽ̨��֧��)
    this.mode = null;
};

module.exports = CaptureImageOptions;

});

define("xFace/extension/CaptureVideoOptions", function(require, exports, module) {

var CaptureVideoOptions = function(){
    //�ڵ����ɼ������ڼ��ܹ��ɼ�����Ƶ�����������ֵ�������趨Ϊ���ڵ���1��Ĭ��ֵΪ1����
    this.limit = 1;
    //һ����Ƶ�������ʱ�䣬��λΪ�롣(androidƽ̨��֧��)
    this.duration = 0;
    //ѡ������Ƶ�ɼ�ģʽ�������趨Ϊcapture.supportedVideoModesö���е�ֵ��(androidƽ̨��֧��)
    this.mode = null;
};

module.exports = CaptureVideoOptions;

});

define("xFace/extension/MediaFile", function(require, exports, module) {
var utils = require('xFace/utils'),
    exec = require('xFace/exec'),
    File = require('xFace/extension/File'),
    CaptureError = require('xFace/extension/CaptureError');
/**
 * ����һ�������Ķ�ý���ļ�.
 *
 * name {DOMString} �ļ���, ������·����Ϣ
 * fullPath {DOMString} �ļ���ȫ·���������ļ���
 * type {DOMString} mime type
 * lastModifiedDate {Date} ����޸�����
 * size {Number} �ļ���С����λ�Ǳ���
 */
var MediaFile = function(name, fullPath, type, lastModifiedDate, size){
    MediaFile.__super__.constructor.apply(this, arguments);
};

utils.extend(MediaFile, File);

/**
 * ����һ��ָ��·�������͵��ļ��ĸ�ʽ��Ϣ
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 */
MediaFile.prototype.getFormatData = function(successCallback, errorCallback) {
    if (typeof this.fullPath === "undefined" || this.fullPath === null) {
        errorCallback(new CaptureError(CaptureError.CAPTURE_INVALID_ARGUMENT));
    } else {
        exec(successCallback, errorCallback, null, "Capture", "getFormatData", [this.fullPath, this.type]);
    }
};

module.exports = MediaFile;

});

define("xFace/extension/MediaFileData", function(require, exports, module) {
/**
 * �� MediaFileData ��װ��һ����ý���ļ��ĸ�ʽ��Ϣ
 *
 * @param {DOMString} codecs
 * @param {long} bitrate
 * @param {long} height
 * @param {long} width
 * @param {float} duration
 */
var MediaFileData = function(codecs, bitrate, height, width, duration){
    this.codecs = codecs || null;
    this.bitrate = bitrate || 0;
    this.height = height || 0;
    this.width = width || 0;
    this.duration = duration || 0;
};

module.exports = MediaFileData;
});

define("xFace/extension/ConfigurationData", function(require, exports, module) {
/**
 * ��װ�豸��֧�ֲ�����һ������
 */
function ConfigurationData() {
    // Сд��ASCII�����ַ�������ʾ��ý������
    this.type = null;
    // height ���Ա�ʾͼƬ������Ƶ�ĸ߶ȣ����أ�
    // �������Ƶ��������Ϊ0
    this.height = 0;
    // width ���Ա�ʾͼƬ������Ƶ�Ŀ��ȣ����أ�
    // �������Ƶ��������Ϊ0
    this.width = 0;
}

module.exports = ConfigurationData;
});

define("xFace/extension/capture", function(require, exports, module) {
var exec = require('xFace/exec'),
    MediaFile = require('xFace/extension/MediaFile');

/**
 * ���ݲ�ͬ��������һ�� capture.
 *
 * @param (DOMString} type  ���Ͱ���:captureImage��captureAudio��captureVideo
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {CaptureImageOptions | CaptureAudioOptions | CaptureVideoOptions} options
 */
function captureMedia(type, successCallback, errorCallback, options) {
    var win = function(result) {
        var mediaFiles = [];
        for (var i = 0; i < result.length; i++) {
            var mediaFile = new MediaFile();
            mediaFile.name = result[i].name;
            mediaFile.fullPath = result[i].fullPath;
            mediaFile.type = result[i].type;
            mediaFile.lastModifiedDate = result[i].lastModifiedDate;
            mediaFile.size = result[i].size;
            mediaFiles.push(mediaFile);
        }
        successCallback(mediaFiles);
    };
    exec(win, errorCallback, null, "Capture", type, [options]);
}
/**
 * ���豸�����������˷��ṩһ�� Capture �ӿ�.
 */
function Capture() {
    this.supportedAudioModes = [];
    this.supportedImageModes = [];
    this.supportedVideoModes = [];
}

/**
 * ���������Ӧ������.
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {CaptureImageOptions} options
 */
Capture.prototype.captureImage = function(successCallback, errorCallback, options){
    captureMedia("captureImage", successCallback, errorCallback, options);
};

/**
 * ���������Ӧ��¼��.
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {CaptureAudioOptions} options
 */
Capture.prototype.captureAudio = function(successCallback, errorCallback, options){
    captureMedia("captureAudio", successCallback, errorCallback, options);
};

/**
 * ���������Ӧ������.
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {CaptureVideoOptions} options
 */
Capture.prototype.captureVideo = function(successCallback, errorCallback, options){
    captureMedia("captureVideo", successCallback, errorCallback, options);
};

module.exports = new Capture();

});

define("xFace/extension/Media", function(require, exports, module) {
var utils = require('xFace/utils'),
    exec = require('xFace/exec');

var mediaObjects = {};

/**
 * �˶����ṩ����豸 Media ������.
 *
 * @constructor
 * @param src                   �ļ������ƻ��� url
 * @param successCallback       �ɹ��ص�
 * @param errorCallback         �쳣�ص�����ѡ��
 * @param statusCallback        ״̬�仯�ص�����ѡ��
 */
var Media = function(src, successCallback, errorCallback, statusCallback) {

    if (successCallback && (typeof successCallback !== "function")) {
        console.log("Media Error: successCallback is not a function");
        return;
    }

    if (errorCallback && (typeof errorCallback !== "function")) {
        console.log("Media Error: errorCallback is not a function");
        return;
    }

    if (statusCallback && (typeof statusCallback !== "function")) {
        console.log("Media Error: statusCallback is not a function");
        return;
    }

    this.id = utils.createUUID();
    mediaObjects[this.id] = this;
    this.src = src;
    this.successCallback = successCallback;
    this.errorCallback = errorCallback;
    this.statusCallback = statusCallback;
    this._duration = -1;
    this._position = -1;
};

// Media messages
Media.MEDIA_STATE = 1;
Media.MEDIA_DURATION = 2;
Media.MEDIA_POSITION = 3;
Media.MEDIA_ERROR = 4;

// Media states
Media.MEDIA_NONE = 0;
Media.MEDIA_STARTING = 1;
Media.MEDIA_RUNNING = 2;
Media.MEDIA_PAUSED = 3;
Media.MEDIA_STOPPED = 4;
Media.MEDIA_MSG = ["None", "Starting", "Running", "Paused", "Stopped"];

// "static" ���������Ѵ��ڵĶ���.
Media.get = function(id) {
    return mediaObjects[id];
};

/**
 * Start ���� resume ���ڲ��ŵ���Ƶ�ļ�.
 *
 * @param options       ��ѡ������Android��Ч��
 */
Media.prototype.play = function(options) {
    exec(null, null, null, "Audio", "play", [this.id, this.src, options]);
};

/**
 * ֹͣ���ڲ��ŵ� audio.
 */
Media.prototype.stop = function() {
    var me = this;
    exec(
        function() {
            me._position = 0;
            me.successCallback();
        },
        this.errorCallback,
        null,
        "Audio", "stop", [this.id]
    );
};


/**
 * Seek ���� jump �����ڲ��ŵ� audio ��һ����λ��.
 */
Media.prototype.seekTo = function(milliseconds) {
    var me = this;
    exec(
        function(p) {
            me._position = p;
        },
        this.errorCallback,
        null,
        "Audio", "seekTo", [this.id, milliseconds]
    );
};

/**
 * ��ͣ���ڲ��ŵ� audio.
 */
Media.prototype.pause = function() {
    exec(null, this.errorCallback, null, "Audio", "pause", [this.id]);
};

/**
 * ��ȡ��ǰ audio �� duration.
 * �� duration ���Դ������в���״̬�� audio ��Ч��playing, paused ���� stopped.
 *
 * @return      duration��֪ʱ�򷵻�ʵ��ֵ�����򷵻� -1.
 */
Media.prototype.getDuration = function() {
    return this._duration;
};

/**
 * ��ȡ audio ��ǰ�Ĳ���λ��.
 *
 * @param success    �ɹ��ص�
 * @param fail       ʧ�ܻص�
 */
Media.prototype.getCurrentPosition = function(success, fail) {
    var me = this;
    exec(
        function(p) {
            me._position = p;
            success(p);
        },
        fail,
        null,
        "Audio", "getCurrentPosition", [this.id]
    );
};

/**
 * �ͷ���Դ.
 */
Media.prototype.release = function() {
    exec(null, this.errorCallback, null, "Audio", "release", [this.id]);
};

/**
 * Audio ��״̬�ص�.
 * PRIVATE
 *
 * @param id            audio ����� id (string)
 * @param status        ״̬�� (int)
 * @param msg           ״̬��Ϣ (string)
 */
Media.onStatus = function(id, msg, value) {
    var media = mediaObjects[id];
    // ���״̬�и���
    if (msg === Media.MEDIA_STATE) {
        if (value === Media.MEDIA_STOPPED) {
            if (media.successCallback) {
                media.successCallback();
            }
        }

        if (media.statusCallback) {
            media.statusCallback(value);
        }
    } else if (msg === Media.MEDIA_DURATION) {
        media._duration = value;
    } else if (msg === Media.MEDIA_ERROR) {
        if (media.errorCallback) {
            media.errorCallback(value);
        }
    } else if (msg === Media.MEDIA_POSITION) {
        media._position = value;
    }
};

module.exports = Media;
});

define("xFace/extension/MediaError", function(require, exports, module) {
/**
 * ������������� Media errors �������Ϣ.
 *
 * @constructor
 */
var MediaError = function(code, msg) {
    this.code = (code !== undefined ? code : null);
    this.message = msg || "";
};

MediaError.MEDIA_ERR_NONE_ACTIVE    = 0;
MediaError.MEDIA_ERR_ABORTED        = 1;
MediaError.MEDIA_ERR_NETWORK        = 2;
MediaError.MEDIA_ERR_DECODE         = 3;
MediaError.MEDIA_ERR_NONE_SUPPORTED = 4;

module.exports = MediaError;
});

define("xFace/extension/android/storage", function(require, exports, module) {
var utils = require('xFace/utils'),
    exec = require('xFace/exec'),
    channel = require('xFace/channel');

var queryQueue = {};

/**
 * SQL������϶���
 */
var DroidDB_Rows = function() {
    this.resultSet = [];    // ���u����
    this.length = 0;        // ����
};

/**
 * ��SQL������϶����л�ȡitem
 *
 * @param row           Ҫ���ص��к�
 * @return              row����
 */
DroidDB_Rows.prototype.item = function(row) {
    return this.resultSet[row];
};

/**
 * ���ظ��û���SQL������϶���.
 */
var DroidDB_Result = function() {
    this.rows = new DroidDB_Rows();
};

/**
 * ����ѯ���ʱ������native����Ļص�.
 * @param id   ��ѯ id
 */
function completeQuery(id, data) {
    var query = queryQueue[id];
    if (query) {
        try {
            delete queryQueue[id];

            // ��ȡ����
            var tx = query.tx;

            if (tx && tx.queryList[id]) {

                // �����ѯ���
                var r = new DroidDB_Result();
                r.rows.resultSet = data;
                r.rows.length = data.length;
                try {
                    if (typeof query.successCallback === 'function') {
                        query.successCallback(query.tx, r);
                    }
                } catch (ex) {
                    console.log("executeSql error calling user success callback: "+ex);
                }

                tx.queryComplete(id);
            }
        } catch (e) {
            console.log("executeSql error: "+e);
        }
    }
}

/**
 * ����ѯʧ��ʱ������native����Ļص�.
 *
 * @param reason            ������Ϣ
 * @param id                ��ѯ id
 */
function failQuery(reason, id) {
    var query = queryQueue[id];
    if (query) {
        try {
            delete queryQueue[id];

            var tx = query.tx;

            if (tx && tx.queryList[id]) {
                tx.queryList = {};

                try {
                    if (typeof query.errorCallback === 'function') {
                        query.errorCallback(query.tx, reason);
                    }
                } catch (ex) {
                    console.log("executeSql error calling user error callback: "+ex);
                }

                tx.queryFailed(id, reason);
            }

        } catch (e) {
            console.log("executeSql error: "+e);
        }
    }
}

/**
 * SQL��ѯ����
 *
 * @param tx                ��ѯ���ڵ��������
 */
var DroidDB_Query = function(tx) {

    // ���ò�ѯ��id
    this.id = utils.createUUID();

    // ���Ӹò�ѯ��������
    queryQueue[this.id] = this;

    // ��ʼ�������
    this.resultSet = [];

    // ���ò�ѯ���ڵ��������
    this.tx = tx;

    // ���Ӳ�ѯ�������б���
    this.tx.queryList[this.id] = this;

    // Callbacks
    this.successCallback = null;
    this.errorCallback = null;

};

/**
 * �������
 */
var DroidDB_Tx = function() {

    // ���������id
    this.id = utils.createUUID();

    // Callbacks
    this.successCallback = null;
    this.errorCallback = null;

    // ��ѯ�б�
    this.queryList = {};
};

/**
 * ����������еĲ�ѯ�ɹ�.
 * ������в�ѯ����ɣ������û�������ɹ��ص�����
 *
 * @param id                ��ѯ id
 */
DroidDB_Tx.prototype.queryComplete = function(id) {
    delete this.queryList[id];

    if (this.successCallback) {
        var count = 0;
        var i;
        for (i in this.queryList) {
            if (this.queryList.hasOwnProperty(i)) {
                count++;
            }
        }
        if (count === 0) {
            try {
                this.successCallback();
            } catch(e) {
                console.log("Transaction error calling user success callback: " + e);
            }
        }
    }
};

/**
 * ����������еĲ�ѯʧ��.
 *
 * @param id                ��ѯ id
 * @param reason            ������Ϣ
 */
DroidDB_Tx.prototype.queryFailed = function(id, reason) {
    this.queryList = {};

    if (this.errorCallback) {
        try {
            this.errorCallback(reason);
        } catch(e) {
            console.log("Transaction error calling user error callback: " + e);
        }
    }
};

/**
 * ִ��SQL���
 *
 * @param sql                   ��ִ�е�SQL���
 * @param params                SQL���Ĳ���
 * @param successCallback       �ɹ��ص�����
 * @param errorCallback         ʧ�ܻص�����
 */
DroidDB_Tx.prototype.executeSql = function(sql, params, successCallback, errorCallback) {

    if (typeof params === 'undefined') {
        params = [];
    }

    var query = new DroidDB_Query(this);
    queryQueue[query.id] = query;

    query.successCallback = successCallback;
    query.errorCallback = errorCallback;

    exec(null, null, null, "Storage", "executeSql", [sql, params, query.id]);
};

var DatabaseShell = function() {
};

/**
 * ��ʼһ������.
 * ��ʧ�ܵ��¼��в�֧�ֻع�.
 *
 * @param process {Function}            ������
 * @param successCallback {Function}
 * @param errorCallback {Function}
 */
DatabaseShell.prototype.transaction = function(process, errorCallback, successCallback) {
    var tx = new DroidDB_Tx();
    tx.successCallback = successCallback;
    tx.errorCallback = errorCallback;
    try {
        process(tx);
    } catch (e) {
        console.log("Transaction error: "+e);
        if (tx.errorCallback) {
            try {
                tx.errorCallback(e);
            } catch (ex) {
                console.log("Transaction error calling user error callback: "+e);
            }
        }
    }
};

/**
 * �����ݿ�
 *
 * @param name              ���ݿ���
 * @param version           ���ݿ�汾
 * @param display_name      ���ݿ���ʾ������
 * @param size              ���ݿ��С����λ:byte��
 * @return                  ���ݿ����
 */
var DroidDB_openDatabase = function(name, version, display_name, size) {
    var db = null;
    var openDatabaseSuccess = function(){
    db = new DatabaseShell();
    };
    var openDatabaseFail = function(){
    db = null;
    };
    exec(openDatabaseSuccess, openDatabaseFail, null, "Storage", "openDatabase", [name, version, display_name, size]);
    return db;
};

module.exports = {
  openDatabase:DroidDB_openDatabase,
  failQuery:failQuery,
  completeQuery:completeQuery
};

});

define("xFace/extension/Camera", function(require, exports, module) {
var exec = require('xFace/exec'),
    Camera = require('xFace/extension/CameraConstants');

var cameraExport = {};

// Tack on the Camera Constants to the base camera plugin.
for (var key in Camera) {
    cameraExport[key] = Camera[key];
}

/**
 * Gets a picture from source defined by "options.sourceType", and returns the
 * image as defined by the "options.destinationType" option.

 * The defaults are sourceType=CAMERA and destinationType=FILE_URL.
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {Object} options
 */
cameraExport.getPicture = function(successCallback, errorCallback, options) {
    // successCallback required
    if (typeof successCallback != "function") {
        console.log("Camera Error: successCallback is not a function");
        return;
    }

    // errorCallback optional
    if (errorCallback && (typeof errorCallback != "function")) {
        console.log("Camera Error: errorCallback is not a function");
        return;
    }

    var quality = 50;
    if (options && typeof options.quality == "number") {
        quality = options.quality;
    } else if (options && typeof options.quality == "string") {
        var qlity = parseInt(options.quality, 10);
        if (isNaN(qlity) === false) {
            quality = qlity.valueOf();
        }
    }

    var destinationType = Camera.DestinationType.FILE_URI;
    if (typeof options.destinationType == "number") {
        destinationType = options.destinationType;
    }

    var sourceType = Camera.PictureSourceType.CAMERA;
    if (typeof options.sourceType == "number") {
        sourceType = options.sourceType;
    }

    var targetWidth = -1;
    if (typeof options.targetWidth == "number") {
        targetWidth = options.targetWidth;
    } else if (typeof options.targetWidth == "string") {
        var width = parseInt(options.targetWidth, 10);
        if (isNaN(width) === false) {
            targetWidth = width.valueOf();
        }
    }

    var targetHeight = -1;
    if (typeof options.targetHeight == "number") {
        targetHeight = options.targetHeight;
    } else if (typeof options.targetHeight == "string") {
        var height = parseInt(options.targetHeight, 10);
        if (isNaN(height) === false) {
            targetHeight = height.valueOf();
        }
    }

    var encodingType = Camera.EncodingType.JPEG;
    if (typeof options.encodingType == "number") {
        encodingType = options.encodingType;
    }

    var mediaType = Camera.MediaType.PICTURE;
    if (typeof options.mediaType == "number") {
        mediaType = options.mediaType;
    }
    var allowEdit = false;
    if (typeof options.allowEdit == "boolean") {
        allowEdit = options.allowEdit;
    } else if (typeof options.allowEdit == "number") {
        allowEdit = options.allowEdit <= 0 ? false : true;
    }
    var correctOrientation = false;
    if (typeof options.correctOrientation == "boolean") {
        correctOrientation = options.correctOrientation;
    } else if (typeof options.correctOrientation == "number") {
        correctOrientation = options.correctOrientation <=0 ? false : true;
    }
    var saveToPhotoAlbum = false;
    if (typeof options.saveToPhotoAlbum == "boolean") {
        saveToPhotoAlbum = options.saveToPhotoAlbum;
    } else if (typeof options.saveToPhotoAlbum == "number") {
        saveToPhotoAlbum = options.saveToPhotoAlbum <=0 ? false : true;
    }

   exec(successCallback, errorCallback, null, "Camera", "takePicture", [quality, destinationType, sourceType, targetWidth, targetHeight, encodingType, mediaType, allowEdit, correctOrientation, saveToPhotoAlbum]);
}

module.exports = cameraExport;

});

define("xFace/extension/CameraConstants", function(require, exports, module) {
module.exports = {
  DestinationType:{
    DATA_URL: 0,         // Return base64 encoded string
    FILE_URI: 1          // Return file uri (content://media/external/images/media/2 for Android)
  },
  EncodingType:{
    JPEG: 0,             // Return JPEG encoded image
    PNG: 1               // Return PNG encoded image
  },
  MediaType:{
    PICTURE: 0,          // allow selection of still pictures only. DEFAULT. Will return format specified via DestinationType
    VIDEO: 1,            // allow selection of video only, ONLY RETURNS URL
    ALLMEDIA : 2         // allow selection from all media types
  },
  PictureSourceType:{
    PHOTOLIBRARY : 0,    // Choose image from picture library (same as SAVEDPHOTOALBUM for Android)
    CAMERA : 1,          // Take picture from camera
    SAVEDPHOTOALBUM : 2  // Choose image from picture library (same as PHOTOLIBRARY for Android)
  }
};

});

define("xFace/extension/Security", function(require, exports, module) {
    var exec = require('xFace/exec');
    var Security = function() {};

/**
 * ����.
 *
 * @param key {String}        ��Կ
 * @param plainText {String}  ����
 * @param successCallback {Function}
 * @param errorCallback {Function}
 */
Security.prototype.encrypt = function(key, plainText, successCallback, errorCallback){
    exec(successCallback, errorCallback, null, "Security", "encrypt", [key, plainText]);
};

/**
 * ����.
 *
 * @param key {String}            ��Կ
 * @param encryptedText {String}  ����
 * @param successCallback {Function}
 * @param errorCallback {Function}
 */
Security.prototype.decrypt = function(key, encryptedText, successCallback, errorCallback){
    exec(successCallback, errorCallback, null, "Security", "decrypt", [key, encryptedText]);
};

module.exports = new Security();

});

define("xFace/extension/AdvancedFileTransfer", function(require, exports, module) {
var exec = require('xFace/exec'),
    DirectoryEntry = require('xFace/extension/DirectoryEntry'),
    FileEntry = require('xFace/extension/FileEntry'),
    ProgressEvent = require('xFace/extension/ProgressEvent');

/**
 * @constructor
 * @param source {String}         �ļ����ڵķ�����URL
 * @param target {String}         ��Ҫ���ص���ָ��·��
 */
var AdvancedFileTransfer = function(source, target) {
    this.source = source;
    this.target = target;
    this.onprogress = null;     // While download the file, and reporting partial download data
};

/**
 * ����һ���ļ���ָ����·��
 * @param successCallback         �ɹ��ص�����
 * @param errorCallback           ʧ�ܻص�����
 */
AdvancedFileTransfer.prototype.download = function(successCallback, errorCallback) {
    var win = function(result) {
        var entry = null;
        if (result.isDirectory) {
            entry = new DirectoryEntry();
        }
        else if (result.isFile) {
            entry = new FileEntry();
        }
        entry.isDirectory = result.isDirectory;
        entry.isFile = result.isFile;
        entry.name = result.name;
        entry.fullPath = result.fullPath;
        successCallback(entry);
    };
    var me = this;
    var s = function(result) {
        if (typeof me.onprogress === "function") {
                me.onprogress(new ProgressEvent("progress", {loaded:result.loaded, total:result.total}));
            }
    };

    exec(win, errorCallback, s, 'AdvancedFileTransfer', 'download', [this.source, this.target]);
};

AdvancedFileTransfer.prototype.pause = function() {
    exec(null, null, null, 'AdvancedFileTransfer', 'pause', [this.source]);
};

module.exports = AdvancedFileTransfer;

});

window.xFace = require('xFace');
require('localStorage');
require('ajax');
(function (context) {
    var channel = require("xFace/channel"),
        _self = {
            boot: function () {

                /**
                 * Create all xFace objects once page has fully loaded and native side is ready.
                 */
                channel.join(function() {
                    var builder = require('xFace/builder'),
                        base = require('xFace/common'),
                        platform = require('xFace/platform');

                    // Drop the common globals into the window object, but be nice and don't overwrite anything.
                    builder.build(base.objects).intoButDontClobber(window);

                    // Drop the platform-specific globals into the window object
                    // and clobber any existing object.
                    builder.build(platform.objects).intoAndClobber(window);
                    // Merge the platform-specific overrides/enhancements into
                    // the window object.
                    if (typeof platform.merges !== 'undefined') {
                      builder.build(platform.merges).intoAndMerge(window);
                   }
                    // Call the platform-specific initialization
                    platform.initialize();
                    // Fire event to notify that all objects are created
                    channel.onxFaceReady.fire();

                    // Fire onDeviceReady event once all constructors have run and
                    // xFace info has been received from native side.
                    channel.join(function() {
                        require('xFace').fireDocumentEvent('deviceready');
                    }, channel.deviceReadyChannelsArray);

                }, [ channel.onDOMContentLoaded, channel.onNativeReady ]);
            }
        };

    // boot up once native side is ready
    channel.onNativeReady.subscribeOnce(_self.boot);

    // _nativeReady is global variable that the native side can set
    // to signify that the native code is ready. It is a global since
    // it may be called before any xFace JS is ready.
    if (window._nativeReady) {
        channel.onNativeReady.fire();
    }

}(window));


})();
